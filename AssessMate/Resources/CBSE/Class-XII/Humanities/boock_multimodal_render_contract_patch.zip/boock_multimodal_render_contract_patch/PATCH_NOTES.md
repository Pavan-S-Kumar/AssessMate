# Patch Notes: Multimodal Render Contract Enforcement

## Why this patch exists

Previous Boock patches added strong upstream artifacts:

- canon context and modality bibles
- screenwriter beat sheet and step outline
- Adaptation Master Script
- production breakdown and department bibles
- scene blocking and camera script
- audio stem/mix/QC/repair
- motion-comic segmented masks
- production continuity validator

This patch makes downstream image, video, audio, and motion-comic pipelines consume those artifacts as mandatory render contracts.

## Major behavior changes

### Image

Before:

```text
chapter text / loose prompt -> image
```

After:

```text
scene_department_packet + reference_lock_manifest + shot/beat context -> image_render_context_pack -> image
```

The image output can now be validated against required characters, costumes, hero props, location, time of day, weather, hard VFX, and style.

### Video

Before:

```text
dialogue timeline / raw prompt -> shot timeline
```

After:

```text
camera_script + scene_department_packet -> contracted_cinematic_shot_timeline -> video_render_prompt_pack
```

The camera script and department packet are mandatory in strict mode.

### Audio

Before:

```text
chapter text -> audio_script
```

After:

```text
performance_timeline + stem_plan + audio_design_packet -> cinematic_audio_render_contract
```

Audiobook and video share the same timed performance base but diverge at mix policy.

### Motion comic

Before:

```text
panel/image -> segmentation
```

After:

```text
AMS/step beats + camera script + scene department packet -> motion_comic_storyboard_plan -> panel render manifest -> segmented layer generation
```

### Publish

Before:

```text
rendered asset -> publish
```

After:

```text
rendered asset -> production continuity validation -> publish gate or targeted repair route
```

## New artifacts

```text
reference_lock_manifest
image_render_context_pack
image_validator_metadata
contracted_cinematic_shot_timeline
video_render_prompt_pack
cinematic_audio_render_contract
cinematic_audio_chunk_manifest
motion_comic_storyboard_plan
motion_comic_panel_render_manifest
gated_publish_manifest
continuity_repair_route_plan
```

## Compatibility

All functions operate on dictionaries and are dependency-free. They can be used directly by existing DB/S3 runners or wrapped inside existing Boock artifact persistence.

## Strict mode

The important builders default to strict mode:

```text
image_render_context_pack requires reference locks
video shot timeline requires camera_script + scene_department_packet
audio contract requires performance_timeline + stem_plan
motion comic storyboard requires scene_department_packet + beats or camera shots
```

Disable only for debugging or transitional migration.
