from __future__ import annotations

import json
from pathlib import Path
import unittest

from boock.audio.cinematic_contract import build_cinematic_audio_render_contract
from boock.image.render_context import build_image_render_context_pack, build_image_validator_metadata, build_reference_lock_manifest
from boock.motion_comic.storyboard_planner import build_motion_comic_storyboard_plan
from boock.production.publish_router import enforce_multimodal_continuity_publish_gate, route_continuity_repair_tickets
from boock.video.contracted_shots import compile_cinematic_shot_timeline_from_camera_script


ROOT = Path(__file__).resolve().parents[1]


def load_example(name: str):
    return json.loads((ROOT / "examples" / name).read_text())


class MultimodalRenderContractTests(unittest.TestCase):
    def setUp(self):
        self.payload = load_example("example_payload.json")
        self.scene_packet = self.payload["scene_department_packet"]
        self.camera_script = self.payload["camera_script"]
        self.performance_timeline = self.payload["performance_timeline"]
        self.stem_plan = self.payload["stem_plan"]

    def test_image_render_context_pack_contains_reference_locks_and_validator_template(self):
        locks = build_reference_lock_manifest(
            book_version_id=self.payload["book_version_id"],
            variant_id=self.payload["variant_id"],
            chapter_id=self.payload["chapter_id"],
            scene_department_packet=self.scene_packet,
            existing_reference_assets=[{"reference_key": "mira", "asset_uri": "s3://x/mira.png"}],
        )
        pack = build_image_render_context_pack(
            book_version_id=self.payload["book_version_id"],
            variant_id=self.payload["variant_id"],
            chapter_id=self.payload["chapter_id"],
            scene_department_packet=self.scene_packet,
            reference_lock_manifest=locks,
            shot={"shot_id": "shot_x", "beat_id": "b001", "subject_ids": ["mira"]},
        )
        self.assertEqual(pack["artifact_type"], "image_render_context_pack")
        self.assertIn("mira", pack["validator_metadata_template"]["required_character_ids"])
        self.assertIn("ruined_watchtower", pack["scene_contract"]["location_id"])
        self.assertTrue(pack["required_department_entry_ids"])

    def test_image_validator_metadata_normalizes_detector_output(self):
        pack = load_example("example_image_render_context_pack.json")
        meta = build_image_validator_metadata(
            image_render_context_pack=pack,
            generated_asset={"asset_id": "a1"},
            detector_output={"detected_character_ids": ["mira"], "detected_location_id": "ruined_watchtower"},
        )
        self.assertEqual(meta["validation_metadata"]["detected_location_id"], "ruined_watchtower")
        self.assertIn("mira", meta["validation_metadata"]["detected_character_ids"])

    def test_video_shot_timeline_requires_camera_script_and_scene_department_packet(self):
        with self.assertRaises(ValueError):
            compile_cinematic_shot_timeline_from_camera_script(
                book_version_id="b",
                variant_id="v",
                chapter_id="c",
                camera_script={},
                scene_department_packet=self.scene_packet,
                strict=True,
            )
        timeline = compile_cinematic_shot_timeline_from_camera_script(
            book_version_id=self.payload["book_version_id"],
            variant_id=self.payload["variant_id"],
            chapter_id=self.payload["chapter_id"],
            camera_script=self.camera_script,
            scene_department_packet=self.scene_packet,
        )
        self.assertEqual(timeline["artifact_type"], "contracted_cinematic_shot_timeline")
        self.assertGreaterEqual(timeline["summary"]["shot_count"], 1)
        self.assertEqual(timeline["shots"][0]["required_location_id"], "ruined_watchtower")

    def test_audio_contract_requires_performance_timeline_and_stem_plan(self):
        with self.assertRaises(ValueError):
            build_cinematic_audio_render_contract(
                book_version_id="b",
                variant_id="v",
                chapter_id="c",
                performance_timeline={},
                stem_plan=self.stem_plan,
            )
        contract = build_cinematic_audio_render_contract(
            book_version_id=self.payload["book_version_id"],
            variant_id=self.payload["variant_id"],
            chapter_id=self.payload["chapter_id"],
            performance_timeline=self.performance_timeline,
            stem_plan=self.stem_plan,
            scene_department_packet=self.scene_packet,
            output_mode="video",
        )
        self.assertEqual(contract["artifact_type"], "cinematic_audio_render_contract")
        self.assertIn("DX_ONSCREEN", contract["required_stem_buses"])
        narrator = [s for s in contract["segments"] if s["line_class"] == "narrator_bridge"][0]
        self.assertFalse(narrator["include_in_video_mix"])

    def test_motion_comic_storyboard_plan_precedes_segmented_layer_generation(self):
        plan = build_motion_comic_storyboard_plan(
            book_version_id=self.payload["book_version_id"],
            variant_id=self.payload["variant_id"],
            chapter_id=self.payload["chapter_id"],
            scene_department_packet=self.scene_packet,
            camera_script=self.camera_script,
        )
        self.assertEqual(plan["artifact_type"], "motion_comic_storyboard_plan")
        self.assertGreaterEqual(plan["summary"]["panel_count"], 1)
        first = plan["panels"][0]
        self.assertIn("background_cleanplate", first["layer_requirements"])
        self.assertIn("character_layers", first["layer_requirements"])
        self.assertIn("prop_layers", first["layer_requirements"])

    def test_continuity_publish_gate_routes_targeted_repairs(self):
        report = {
            "production_continuity_validation_report_id": "r1",
            "state": "needs_repair",
            "issues": [
                {"category": "missing_hero_prop", "severity": "blocker", "scene_id": "s1", "shot_id": "sh1"},
                {"category": "missing_sound_cue", "severity": "repair", "scene_id": "s1"},
            ],
        }
        gated = enforce_multimodal_continuity_publish_gate(
            publish_manifest={"publish_manifest_id": "p1"},
            continuity_report=report,
        )
        self.assertFalse(gated["can_publish"])
        self.assertEqual(gated["publish_gate_state"], "blocked_by_production_continuity")
        route = route_continuity_repair_tickets(continuity_report=report)
        self.assertIn("generate_prop_layer_or_rerender_shot", route["route_groups"])
        self.assertIn("patch_sound_plan_or_stem_manifest", route["route_groups"])


if __name__ == "__main__":
    unittest.main()
