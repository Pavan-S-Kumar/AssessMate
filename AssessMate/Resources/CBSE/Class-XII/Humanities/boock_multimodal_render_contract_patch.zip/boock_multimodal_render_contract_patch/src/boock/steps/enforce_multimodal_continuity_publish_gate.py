from __future__ import annotations

from typing import Any, Dict

from boock.production.publish_router import enforce_multimodal_continuity_publish_gate


def run_enforce_multimodal_continuity_publish_gate(input_payload: Dict[str, Any]) -> Dict[str, Any]:
    gated = enforce_multimodal_continuity_publish_gate(
        publish_manifest=input_payload["publish_manifest"],
        continuity_report=input_payload["continuity_report"],
        strict=bool(input_payload.get("strict", True)),
    )
    return {**input_payload, "gated_publish_manifest": gated}
