from __future__ import annotations

from typing import Any, Dict, List, Mapping, Optional

from boock.render_contracts.common import (
    JsonDict,
    as_list,
    dedupe,
    find_scene_in_camera_script,
    join_prompt_lines,
    nonempty_str,
    required_ids_from_scene_packet,
    scene_from_department_packet,
    stable_id,
    summarize_scene_department_packet,
)


def _extract_ams_beats(ams_or_step_outline: Mapping[str, Any], scene_id: str) -> List[JsonDict]:
    # Step outline scene cards
    for key in ("scene_cards", "scenes"):
        for scene in as_list(ams_or_step_outline.get(key)):
            if not isinstance(scene, Mapping):
                continue
            if scene_id and nonempty_str(scene.get("scene_id") or scene.get("ams_scene_id") or scene.get("scene_card_id")) not in {scene_id, ""}:
                # allow step_outline cards with no AMS scene ID; don't reject all below
                pass
            beats = as_list(scene.get("beats") or scene.get("source_beats") or scene.get("source_beat_ids"))
            if beats:
                out: List[JsonDict] = []
                for idx, beat in enumerate(beats, start=1):
                    if isinstance(beat, Mapping):
                        row = dict(beat)
                    else:
                        row = {"beat_id": str(beat)}
                    row.setdefault("ordinal", idx)
                    out.append(row)
                return out

    # AMS style: scenes[].beats
    for scene in as_list(ams_or_step_outline.get("scenes")):
        if isinstance(scene, Mapping) and (not scene_id or nonempty_str(scene.get("scene_id")) == scene_id):
            beats = as_list(scene.get("beats"))
            if beats:
                return [dict(x) for x in beats if isinstance(x, Mapping)]

    # Flat beats fallback
    beats = as_list(ams_or_step_outline.get("beats"))
    if beats:
        return [dict(x) if isinstance(x, Mapping) else {"beat_id": str(x)} for x in beats]
    return []


def build_motion_comic_storyboard_plan(
    *,
    book_version_id: str,
    variant_id: str,
    chapter_id: str,
    scene_department_packet: Mapping[str, Any],
    ams_or_step_outline: Optional[Mapping[str, Any]] = None,
    camera_script: Optional[Mapping[str, Any]] = None,
    motion_comic_design_packet: Optional[Mapping[str, Any]] = None,
    reference_lock_manifest: Optional[Mapping[str, Any]] = None,
    panels_per_beat: int = 1,
    strict: bool = True,
) -> JsonDict:
    """Plan panels/storyboard before segmented layer generation."""
    if strict and not scene_department_packet:
        raise ValueError("scene_department_packet is mandatory for motion-comic storyboard planning")

    scene = scene_from_department_packet(scene_department_packet)
    required = required_ids_from_scene_packet(scene_department_packet)
    summary = summarize_scene_department_packet(scene_department_packet)
    scene_id = required["scene_id"]

    camera_shots: List[JsonDict] = []
    if camera_script:
        try:
            camera_scene = find_scene_in_camera_script(camera_script, scene_id)
            camera_shots = [dict(x) for x in as_list(camera_scene.get("shots")) if isinstance(x, Mapping)]
        except Exception:
            camera_shots = []

    beats = _extract_ams_beats(ams_or_step_outline or {}, scene_id)
    if not beats and camera_shots:
        beats = [
            {
                "beat_id": nonempty_str(shot.get("beat_id"), f"beat_from_{shot.get('shot_id')}"),
                "story_function": nonempty_str(shot.get("coverage_role") or shot.get("render_mode")),
                "line_class": nonempty_str((shot.get("dialogue_anchor") or {}).get("line_class") if isinstance(shot.get("dialogue_anchor"), dict) else ""),
            }
            for shot in camera_shots
        ]
    if strict and not beats:
        raise ValueError("ams_or_step_outline or camera_script must provide beats for motion-comic storyboard planning")

    design = motion_comic_design_packet or {}
    downstream_mc = (scene_department_packet.get("downstream_contract") or {}).get("motion_comic", {}) if isinstance(scene_department_packet.get("downstream_contract"), dict) else {}
    panels: List[JsonDict] = []
    shot_by_beat: Dict[str, List[JsonDict]] = {}
    for shot in camera_shots:
        bid = nonempty_str(shot.get("beat_id"))
        shot_by_beat.setdefault(bid, []).append(shot)

    panel_idx = 1
    for beat in beats:
        beat_id = nonempty_str(beat.get("beat_id"), f"beat_{panel_idx:04d}")
        related_shots = shot_by_beat.get(beat_id, [])
        count = max(1, panels_per_beat)
        if related_shots:
            count = max(count, len(related_shots))
        for local_idx in range(count):
            shot = related_shots[min(local_idx, len(related_shots)-1)] if related_shots else {}
            subject_ids = [x for x in as_list(shot.get("subject_ids")) if isinstance(x, str) and x] or required["required_character_ids"]
            prop_ids = []
            meta = shot.get("metadata") if isinstance(shot.get("metadata"), dict) else {}
            for p in as_list(meta.get("prop_interactions")):
                if isinstance(p, Mapping) and nonempty_str(p.get("prop_id")):
                    prop_ids.append(nonempty_str(p.get("prop_id")))
            if not prop_ids:
                prop_ids = required["required_hero_prop_ids"]

            panel_id = f"{scene_id}.panel.{panel_idx:04d}"
            panels.append(
                {
                    "panel_id": panel_id,
                    "scene_id": scene_id,
                    "beat_id": beat_id,
                    "source_shot_id": nonempty_str(shot.get("shot_id")),
                    "ordinal": panel_idx,
                    "panel_role": nonempty_str(shot.get("coverage_role") or beat.get("beat_category") or beat.get("story_function") or "story_beat"),
                    "composition": {
                        "shot_size": nonempty_str(shot.get("shot_size") or "medium"),
                        "camera_move_hint": nonempty_str(shot.get("camera_move") or "subtle_parallax"),
                        "subject_ids": subject_ids,
                        "focus_target_id": nonempty_str(shot.get("eyeline_target_id") or (subject_ids[0] if subject_ids else "")),
                        "background_anchor": downstream_mc.get("layer_background") or required["required_location_id"],
                        "location_identity_markers": summary.get("background_identity_markers"),
                    },
                    "layer_requirements": {
                        "background_cleanplate": {
                            "required": True,
                            "location_id": required["required_location_id"],
                            "set_dressing": summary.get("set_dressing"),
                            "palette": summary.get("palette"),
                        },
                        "character_layers": [
                            {
                                "character_id": cid,
                                "layer_kinds": ["full_body", "head_face_micro_motion"],
                                "costume_id": next((w.get("costume_id") for w in as_list(scene.get("wardrobe")) if isinstance(w, Mapping) and w.get("character_id") == cid), ""),
                            }
                            for cid in subject_ids if cid in required["required_character_ids"]
                        ],
                        "prop_layers": [
                            {
                                "prop_id": pid,
                                "layer_kinds": ["hero_prop_insert" if pid in required["required_hero_prop_ids"] else "prop_interaction"],
                                "story_critical": pid in required["required_hero_prop_ids"],
                            }
                            for pid in dedupe(prop_ids)
                        ],
                        "foreground_occlusion_layer": True,
                        "speech_balloon_or_subtitle_safe_area": "lower_third_or_side_rail",
                    },
                    "motion_requirements": {
                        "camera_parallax": "subtle",
                        "face_micro_motion": True,
                        "mouth_motion": nonempty_str(beat.get("line_class")) in {"onscreen_dialogue", "dialogue"},
                        "prop_micro_motion": bool(prop_ids),
                    },
                    "dialogue_or_caption": nonempty_str(beat.get("text") or beat.get("dialogue_intent") or beat.get("plot_function")),
                    "sfx_cues": [nonempty_str(x.get("description") if isinstance(x, Mapping) else x) for x in as_list(summary.get("sound")) if nonempty_str(x.get("description") if isinstance(x, Mapping) else x)],
                    "required_canon_fact_ids": required["required_canon_fact_ids"],
                    "required_reference_lock_ids": as_list((reference_lock_manifest or {}).get("required_lock_ids")),
                }
            )
            panel_idx += 1

    plan_id = stable_id("motion_comic_storyboard_plan", book_version_id, variant_id, chapter_id, scene_id, len(panels))
    return {
        "artifact_type": "motion_comic_storyboard_plan",
        "version": "0.1.0",
        "motion_comic_storyboard_plan_id": plan_id,
        "book_version_id": book_version_id,
        "variant_id": variant_id,
        "chapter_id": chapter_id,
        "scene_id": scene_id,
        "script_version_id": required["script_version_id"],
        "scene_department_packet_id": scene_department_packet.get("scene_department_packet_id", ""),
        "motion_comic_design_packet_id": (motion_comic_design_packet or {}).get("motion_comic_design_packet_id", ""),
        "camera_script_id": (camera_script or {}).get("camera_script_id", ""),
        "source_scope_ids": required["source_scope_ids"],
        "required_canon_fact_ids": required["required_canon_fact_ids"],
        "panels": panels,
        "summary": {
            "panel_count": len(panels),
            "character_layer_count": sum(len(p.get("layer_requirements", {}).get("character_layers", [])) for p in panels),
            "prop_layer_count": sum(len(p.get("layer_requirements", {}).get("prop_layers", [])) for p in panels),
        },
        "provenance": {"generator": "build_motion_comic_storyboard_plan_v1"},
    }


def build_motion_comic_panel_render_manifest(
    *,
    motion_comic_storyboard_plan: Mapping[str, Any],
    reference_lock_manifest: Optional[Mapping[str, Any]] = None,
) -> JsonDict:
    panels = [dict(x) for x in as_list(motion_comic_storyboard_plan.get("panels")) if isinstance(x, Mapping)]
    render_jobs = []
    for panel in panels:
        render_jobs.append(
            {
                "panel_id": panel.get("panel_id", ""),
                "scene_id": panel.get("scene_id", ""),
                "beat_id": panel.get("beat_id", ""),
                "job_type": "motion_comic_panel_layers",
                "requires_background_cleanplate": bool(panel.get("layer_requirements", {}).get("background_cleanplate", {}).get("required")),
                "required_character_layers": panel.get("layer_requirements", {}).get("character_layers", []),
                "required_prop_layers": panel.get("layer_requirements", {}).get("prop_layers", []),
                "segmented_layer_planner_input": {
                    "panel_id": panel.get("panel_id", ""),
                    "background_anchor": panel.get("composition", {}).get("background_anchor", ""),
                    "subject_ids": panel.get("composition", {}).get("subject_ids", []),
                    "prop_ids": [p.get("prop_id") for p in panel.get("layer_requirements", {}).get("prop_layers", [])],
                    "reference_lock_ids": panel.get("required_reference_lock_ids", []),
                },
                "prompt": join_prompt_lines(
                    [
                        f"panel {panel.get('panel_id')} role {panel.get('panel_role')}",
                        f"composition subjects {', '.join(panel.get('composition', {}).get('subject_ids', []))}",
                        f"background {panel.get('composition', {}).get('background_anchor')}",
                        f"caption/dialogue {panel.get('dialogue_or_caption')}",
                    ]
                ),
            }
        )
    return {
        "artifact_type": "motion_comic_panel_render_manifest",
        "version": "0.1.0",
        "motion_comic_panel_render_manifest_id": stable_id("motion_comic_panel_render_manifest", motion_comic_storyboard_plan.get("motion_comic_storyboard_plan_id"), reference_lock_manifest and reference_lock_manifest.get("reference_lock_manifest_id")),
        "source_storyboard_plan_id": motion_comic_storyboard_plan.get("motion_comic_storyboard_plan_id", ""),
        "reference_lock_manifest_id": (reference_lock_manifest or {}).get("reference_lock_manifest_id", ""),
        "render_jobs": render_jobs,
        "summary": {"render_job_count": len(render_jobs)},
        "provenance": {"generator": "build_motion_comic_panel_render_manifest_v1"},
    }
