from __future__ import annotations

from typing import Any, Dict

from boock.video.contracted_shots import compile_cinematic_shot_timeline_from_camera_script


def run_compile_cinematic_shot_timeline_from_contracts(input_payload: Dict[str, Any]) -> Dict[str, Any]:
    timeline = compile_cinematic_shot_timeline_from_camera_script(
        book_version_id=str(input_payload["book_version_id"]),
        variant_id=str(input_payload["variant_id"]),
        chapter_id=str(input_payload.get("chapter_id", "")),
        camera_script=input_payload["camera_script"],
        scene_department_packet=input_payload["scene_department_packet"],
        reference_lock_manifest=input_payload.get("reference_lock_manifest"),
        strict=bool(input_payload.get("strict", True)),
    )
    return {**input_payload, "contracted_cinematic_shot_timeline": timeline}
