from __future__ import annotations

from typing import Any, Dict

from boock.motion_comic.storyboard_planner import build_motion_comic_panel_render_manifest


def run_build_motion_comic_panel_render_manifest(input_payload: Dict[str, Any]) -> Dict[str, Any]:
    manifest = build_motion_comic_panel_render_manifest(
        motion_comic_storyboard_plan=input_payload["motion_comic_storyboard_plan"],
        reference_lock_manifest=input_payload.get("reference_lock_manifest"),
    )
    return {**input_payload, "motion_comic_panel_render_manifest": manifest}
