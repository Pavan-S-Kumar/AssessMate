from __future__ import annotations

from typing import Any, Dict

from boock.image.render_context import build_reference_lock_manifest


def run_build_image_reference_locks(input_payload: Dict[str, Any]) -> Dict[str, Any]:
    manifest = build_reference_lock_manifest(
        book_version_id=str(input_payload["book_version_id"]),
        variant_id=str(input_payload["variant_id"]),
        chapter_id=str(input_payload.get("chapter_id", "")),
        scene_department_packet=input_payload["scene_department_packet"],
        department_bibles_bundle=input_payload.get("department_bibles_bundle"),
        existing_reference_assets=input_payload.get("existing_reference_assets") or [],
        lock_revision=int(input_payload.get("lock_revision") or 1),
    )
    return {**input_payload, "reference_lock_manifest": manifest}
