from __future__ import annotations

from typing import Any, Dict

from boock.audio.cinematic_contract import build_cinematic_audio_render_contract


def run_build_cinematic_audio_render_contract(input_payload: Dict[str, Any]) -> Dict[str, Any]:
    contract = build_cinematic_audio_render_contract(
        book_version_id=str(input_payload["book_version_id"]),
        variant_id=str(input_payload["variant_id"]),
        chapter_id=str(input_payload.get("chapter_id", "")),
        performance_timeline=input_payload["performance_timeline"],
        stem_plan=input_payload["stem_plan"],
        audio_design_packet=input_payload.get("audio_design_packet"),
        scene_department_packet=input_payload.get("scene_department_packet"),
        output_mode=str(input_payload.get("output_mode") or "audiobook"),
        strict=bool(input_payload.get("strict", True)),
    )
    return {**input_payload, "cinematic_audio_render_contract": contract}
