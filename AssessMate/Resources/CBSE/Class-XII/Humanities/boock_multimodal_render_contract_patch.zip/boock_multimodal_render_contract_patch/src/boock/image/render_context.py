from __future__ import annotations

import json
from typing import Any, Dict, List, Mapping, Optional

from boock.render_contracts.common import (
    JsonDict,
    as_list,
    by_id,
    dedupe,
    get_nested,
    hard_vfx_ids,
    join_prompt_lines,
    nonempty_str,
    required_ids_from_scene_packet,
    scene_from_department_packet,
    stable_id,
    summarize_scene_department_packet,
)


def _asset_lookup(existing_reference_assets: Any) -> Dict[str, JsonDict]:
    lookup: Dict[str, JsonDict] = {}
    for asset in as_list(existing_reference_assets):
        if not isinstance(asset, Mapping):
            continue
        for key in (
            asset.get("reference_key"),
            asset.get("character_id"),
            asset.get("costume_id"),
            asset.get("prop_id"),
            asset.get("location_id"),
            asset.get("style_id"),
            asset.get("lock_id"),
        ):
            if isinstance(key, str) and key.strip():
                lookup[key.strip()] = dict(asset)
    return lookup


def build_reference_lock_manifest(
    *,
    book_version_id: str,
    variant_id: str,
    chapter_id: str,
    scene_department_packet: Mapping[str, Any],
    department_bibles_bundle: Optional[Mapping[str, Any]] = None,
    existing_reference_assets: Optional[List[Mapping[str, Any]]] = None,
    lock_revision: int = 1,
) -> JsonDict:
    """Build persistent reference locks for visual generation.

    The manifest does not generate images by itself. It declares what visual references
    must exist before production image/video/motion-comic renders can be trusted.
    """
    scene = scene_from_department_packet(scene_department_packet)
    summary = summarize_scene_department_packet(scene_department_packet)
    required = required_ids_from_scene_packet(scene_department_packet)
    assets = _asset_lookup(existing_reference_assets or [])
    bibles = department_bibles_bundle or {}

    locks: List[JsonDict] = []

    def _lock(kind: str, entity_id: str, *, extra: Optional[Mapping[str, Any]] = None) -> JsonDict:
        if not entity_id:
            return {}
        asset = assets.get(entity_id) or assets.get(f"{kind}:{entity_id}") or {}
        lock_id = stable_id(f"{kind}_lock", book_version_id, variant_id, scene.get("script_version_id"), entity_id, lock_revision)
        status = "locked" if asset.get("asset_uri") or asset.get("s3_uri") or asset.get("uri") else "needs_reference"
        return {
            "lock_id": lock_id,
            "lock_kind": kind,
            "entity_id": entity_id,
            "status": status,
            "reference_asset_uri": asset.get("asset_uri") or asset.get("s3_uri") or asset.get("uri") or "",
            "reference_asset_id": asset.get("asset_id") or asset.get("artifact_id") or "",
            "revision": lock_revision,
            "constraints": dict(extra or {}),
        }

    costume_by_character = {}
    for w in as_list(scene.get("wardrobe")):
        if isinstance(w, Mapping):
            cid = nonempty_str(w.get("character_id"))
            costume_by_character[cid] = nonempty_str(w.get("costume_id") or w.get("default_costume_id"))

    for char_id in required["required_character_ids"]:
        locks.append(
            _lock(
                "character",
                char_id,
                extra={
                    "costume_id": costume_by_character.get(char_id, ""),
                    "scene_id": required["scene_id"],
                    "must_preserve_identity": True,
                },
            )
        )

    for costume_id in required["required_costume_ids"]:
        costume_entry = {}
        for c in as_list(scene_department_packet.get("required_costumes")):
            if isinstance(c, Mapping) and costume_id in {
                nonempty_str(c.get("default_costume_id")),
                nonempty_str(c.get("costume_id")),
                nonempty_str(c.get("costume_entry_id")),
            }:
                costume_entry = dict(c)
                break
        locks.append(
            _lock(
                "costume",
                costume_id,
                extra={
                    "scene_id": required["scene_id"],
                    "palette": costume_entry.get("palette") or summary.get("palette"),
                    "condition_rules": costume_entry.get("condition_rules") or [],
                    "must_preserve_continuity": True,
                },
            )
        )

    for prop_id in required["required_prop_ids"]:
        prop = {}
        for p in as_list(scene.get("props")) + as_list(scene_department_packet.get("required_props")):
            if isinstance(p, Mapping) and prop_id in {nonempty_str(p.get("prop_id")), nonempty_str(p.get("name"))}:
                prop = dict(p)
                break
        locks.append(
            _lock(
                "prop",
                prop_id,
                extra={
                    "scene_id": required["scene_id"],
                    "story_critical": bool(prop.get("story_critical") or prop_id in required["required_hero_prop_ids"]),
                    "visibility": prop.get("visibility") or prop.get("default_visibility") or "",
                    "must_preserve_shape": bool(prop.get("story_critical") or prop_id in required["required_hero_prop_ids"]),
                },
            )
        )

    if required["required_location_id"]:
        locks.append(
            _lock(
                "location",
                required["required_location_id"],
                extra={
                    "scene_id": required["scene_id"],
                    "location_name": summary.get("location_name"),
                    "background_identity_markers": summary.get("background_identity_markers"),
                    "set_dressing": summary.get("set_dressing"),
                    "palette": summary.get("palette"),
                },
            )
        )

    color_id = stable_id("color_style", book_version_id, variant_id, required["scene_id"], tuple(summary.get("palette") or []), lock_revision)
    locks.append(
        {
            "lock_id": color_id,
            "lock_kind": "color_style",
            "entity_id": color_id,
            "status": "locked" if summary.get("palette") else "needs_reference",
            "reference_asset_uri": "",
            "reference_asset_id": "",
            "revision": lock_revision,
            "constraints": {
                "scene_id": required["scene_id"],
                "palette": summary.get("palette"),
                "lighting_intent": summary.get("lighting_intent"),
                "weather": required["weather"],
                "time_of_day": required["time_of_day"],
            },
        }
    )

    locks = [l for l in locks if l]
    manifest_id = stable_id("reference_lock_manifest", book_version_id, variant_id, chapter_id, required["scene_id"], lock_revision)
    return {
        "artifact_type": "reference_lock_manifest",
        "version": "0.1.0",
        "reference_lock_manifest_id": manifest_id,
        "book_version_id": book_version_id,
        "variant_id": variant_id,
        "chapter_id": chapter_id,
        "scene_id": required["scene_id"],
        "script_version_id": required["script_version_id"],
        "lock_revision": lock_revision,
        "locks": dedupe(locks),
        "required_lock_ids": [l["lock_id"] for l in locks],
        "needs_reference_lock_ids": [l["lock_id"] for l in locks if l.get("status") != "locked"],
        "source_scope_ids": required["source_scope_ids"],
        "required_canon_fact_ids": required["required_canon_fact_ids"],
        "provenance": {
            "generator": "build_reference_lock_manifest_v1",
            "scene_department_packet_id": scene_department_packet.get("scene_department_packet_id", ""),
            "department_bibles_bundle_id": (department_bibles_bundle or {}).get("department_bibles_bundle_id", ""),
        },
        "summary": {
            "lock_count": len(locks),
            "needs_reference_count": sum(1 for l in locks if l.get("status") != "locked"),
            "character_count": len([l for l in locks if l["lock_kind"] == "character"]),
            "prop_count": len([l for l in locks if l["lock_kind"] == "prop"]),
        },
    }


def build_image_render_context_pack(
    *,
    book_version_id: str,
    variant_id: str,
    chapter_id: str,
    scene_department_packet: Mapping[str, Any],
    reference_lock_manifest: Mapping[str, Any],
    shot: Optional[Mapping[str, Any]] = None,
    modality_contract: Optional[Mapping[str, Any]] = None,
    canon_contract: Optional[Mapping[str, Any]] = None,
    image_task: str = "shot_keyframe",
    strict: bool = True,
) -> JsonDict:
    if strict and not reference_lock_manifest.get("locks"):
        raise ValueError("reference_lock_manifest with locks is required for image generation")
    scene = scene_from_department_packet(scene_department_packet)
    summary = summarize_scene_department_packet(scene_department_packet)
    required = required_ids_from_scene_packet(scene_department_packet)
    shot = dict(shot or {})
    shot_id = nonempty_str(shot.get("shot_id"))
    beat_id = nonempty_str(shot.get("beat_id"))

    subject_ids = [x for x in as_list(shot.get("subject_ids")) if isinstance(x, str) and x.strip()]
    if not subject_ids:
        subject_ids = required["required_character_ids"]

    shot_meta = shot.get("metadata") if isinstance(shot.get("metadata"), dict) else shot.get("meta") if isinstance(shot.get("meta"), dict) else {}
    shot_prop_ids = [
        nonempty_str(p.get("prop_id"))
        for p in as_list(shot_meta.get("prop_interactions"))
        if isinstance(p, Mapping) and nonempty_str(p.get("prop_id"))
    ]
    prop_ids = dedupe(shot_prop_ids + required["required_hero_prop_ids"])

    modality_required_ids = as_list((modality_contract or {}).get("required_entry_ids")) + as_list((modality_contract or {}).get("required_modality_entry_ids"))
    canon_required_ids = dedupe(required["required_canon_fact_ids"] + as_list((canon_contract or {}).get("required_fact_ids")) + as_list(shot.get("required_canon_fact_ids")))

    positive_lines = [
        f"scene {required['scene_id']} / {summary.get('slugline')}",
        f"dramatic function: {summary.get('dramatic_function')}",
        f"emotional turn: {summary.get('emotional_turn')}",
        f"location: {required['required_location_id']} {summary.get('location_name')}",
        f"time/weather: {required['time_of_day']} / {required['weather']}",
        f"shot: {shot.get('shot_size') or shot.get('shot_type') or image_task}; movement: {shot.get('camera_move') or shot.get('movement') or ''}",
        f"subjects: {', '.join(subject_ids)}",
        f"required props: {', '.join(prop_ids)}",
        f"palette: {', '.join(summary.get('palette') or [])}",
        f"set dressing: {', '.join(summary.get('set_dressing') or [])}",
        f"background markers: {', '.join(summary.get('background_identity_markers') or [])}",
    ]
    negative_lines = list(summary.get("director_do_not") or []) + [
        "do not change character identity, age, costume, hero props, location, weather, or time of day",
        "do not reveal future canon facts or hidden story information",
        "do not invent modern objects, signage, or clothing unless present in the department packet",
    ]

    context_id = stable_id(
        "image_render_context_pack",
        book_version_id,
        variant_id,
        chapter_id,
        required["scene_id"],
        beat_id,
        shot_id,
        image_task,
    )
    return {
        "artifact_type": "image_render_context_pack",
        "version": "0.1.0",
        "image_render_context_pack_id": context_id,
        "book_version_id": book_version_id,
        "variant_id": variant_id,
        "chapter_id": chapter_id,
        "script_version_id": required["script_version_id"],
        "scene_id": required["scene_id"],
        "beat_id": beat_id,
        "shot_id": shot_id,
        "image_task": image_task,
        "source_scope_ids": required["source_scope_ids"],
        "required_canon_fact_ids": canon_required_ids,
        "required_modality_entry_ids": dedupe([str(x) for x in modality_required_ids if str(x).strip()]),
        "required_department_entry_ids": dedupe(reference_lock_manifest.get("required_lock_ids", [])),
        "scene_contract": {
            "location_id": required["required_location_id"],
            "location_name": summary.get("location_name"),
            "time_of_day": required["time_of_day"],
            "weather": required["weather"],
            "palette": summary.get("palette"),
            "lighting_intent": summary.get("lighting_intent"),
            "set_dressing": summary.get("set_dressing"),
            "background_identity_markers": summary.get("background_identity_markers"),
            "hard_vfx_ids": hard_vfx_ids(scene_department_packet),
        },
        "character_contracts": [
            {
                "character_id": cid,
                "must_be_visible": cid in subject_ids,
                "costume_id": next((w.get("costume_id") for w in as_list(scene.get("wardrobe")) if isinstance(w, Mapping) and w.get("character_id") == cid), ""),
            }
            for cid in required["required_character_ids"]
        ],
        "prop_contracts": [
            {
                "prop_id": pid,
                "must_be_visible": pid in prop_ids or pid in required["required_hero_prop_ids"],
                "story_critical": pid in required["required_hero_prop_ids"],
            }
            for pid in required["required_prop_ids"]
        ],
        "reference_locks": reference_lock_manifest.get("locks", []),
        "prompt_blocks": {
            "positive_prompt": join_prompt_lines(positive_lines),
            "negative_prompt": join_prompt_lines(negative_lines),
            "continuity_prompt": join_prompt_lines(
                [
                    f"required canon facts: {', '.join(canon_required_ids)}",
                    f"required reference locks: {', '.join(reference_lock_manifest.get('required_lock_ids', []))}",
                    "visible elements must match validator metadata after render",
                ]
            ),
        },
        "validator_metadata_template": {
            "required_character_ids": required["required_character_ids"],
            "required_costume_ids": required["required_costume_ids"],
            "required_prop_ids": required["required_prop_ids"],
            "required_hero_prop_ids": required["required_hero_prop_ids"],
            "required_location_id": required["required_location_id"],
            "required_time_of_day": required["time_of_day"],
            "required_weather": required["weather"],
            "required_hard_vfx_ids": hard_vfx_ids(scene_department_packet),
            "detected_character_ids": [],
            "detected_costume_ids": [],
            "detected_prop_ids": [],
            "detected_location_id": "",
            "detected_time_of_day": "",
            "detected_weather": "",
            "detected_vfx_ids": [],
            "continuity_score": None,
            "style_score": None,
        },
        "provenance": {
            "generator": "build_image_render_context_pack_v1",
            "scene_department_packet_id": scene_department_packet.get("scene_department_packet_id", ""),
            "reference_lock_manifest_id": reference_lock_manifest.get("reference_lock_manifest_id", ""),
        },
    }


def build_image_validator_metadata(
    *,
    image_render_context_pack: Mapping[str, Any],
    generated_asset: Optional[Mapping[str, Any]] = None,
    detector_output: Optional[Mapping[str, Any]] = None,
) -> JsonDict:
    """Normalize detector/render metadata into the shape expected by continuity validation."""
    template = dict(image_render_context_pack.get("validator_metadata_template") or {})
    detector_output = detector_output or {}
    generated_asset = generated_asset or {}
    meta = dict(template)
    for key in (
        "detected_character_ids",
        "detected_costume_ids",
        "detected_prop_ids",
        "detected_vfx_ids",
    ):
        meta[key] = dedupe(as_list(detector_output.get(key) or generated_asset.get(key) or meta.get(key)))
    for key in ("detected_location_id", "detected_time_of_day", "detected_weather"):
        meta[key] = nonempty_str(detector_output.get(key) or generated_asset.get(key) or meta.get(key))
    meta["continuity_score"] = detector_output.get("continuity_score", generated_asset.get("continuity_score", meta.get("continuity_score")))
    meta["style_score"] = detector_output.get("style_score", generated_asset.get("style_score", meta.get("style_score")))
    return {
        "artifact_type": "image_validator_metadata",
        "version": "0.1.0",
        "image_validator_metadata_id": stable_id(
            "image_validator_metadata",
            image_render_context_pack.get("image_render_context_pack_id"),
            generated_asset.get("asset_id") or generated_asset.get("artifact_id") or generated_asset.get("s3_uri"),
        ),
        "scene_id": image_render_context_pack.get("scene_id", ""),
        "beat_id": image_render_context_pack.get("beat_id", ""),
        "shot_id": image_render_context_pack.get("shot_id", ""),
        "source_context_pack_id": image_render_context_pack.get("image_render_context_pack_id", ""),
        "asset": dict(generated_asset),
        "validation_metadata": meta,
        "provenance": {"generator": "build_image_validator_metadata_v1"},
    }
