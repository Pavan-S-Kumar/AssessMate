from __future__ import annotations

import copy
import hashlib
import json
import re
from typing import Any, Dict, Iterable, List, Mapping, MutableMapping, Optional, Sequence, Tuple


JsonDict = Dict[str, Any]


def stable_id(prefix: str, *parts: Any, length: int = 12) -> str:
    """Create a deterministic short ID from structured parts."""
    raw = json.dumps(parts, sort_keys=True, ensure_ascii=False, default=str)
    digest = hashlib.sha256(raw.encode("utf-8")).hexdigest()[:length]
    clean = re.sub(r"[^a-zA-Z0-9_]+", "_", prefix.strip().lower()).strip("_") or "id"
    return f"{clean}_{digest}"


def deep_copy(obj: Any) -> Any:
    return copy.deepcopy(obj)


def as_list(value: Any) -> List[Any]:
    if value is None:
        return []
    if isinstance(value, list):
        return value
    if isinstance(value, tuple):
        return list(value)
    return [value]


def list_ids(values: Any, *candidate_keys: str) -> List[str]:
    """Normalize a list of strings/dicts into stable string IDs."""
    out: List[str] = []
    for item in as_list(values):
        if isinstance(item, str):
            v = item.strip()
            if v:
                out.append(v)
            continue
        if isinstance(item, Mapping):
            for key in candidate_keys:
                v = item.get(key)
                if isinstance(v, str) and v.strip():
                    out.append(v.strip())
                    break
    return dedupe(out)


def dedupe(values: Iterable[Any]) -> List[Any]:
    seen = set()
    out = []
    for value in values:
        key = json.dumps(value, sort_keys=True, ensure_ascii=False, default=str) if isinstance(value, (dict, list)) else str(value)
        if key in seen:
            continue
        seen.add(key)
        out.append(value)
    return out


def nonempty_str(value: Any, default: str = "") -> str:
    if value is None:
        return default
    s = str(value).strip()
    return s if s else default


def require_dict(doc: Mapping[str, Any], key: str, *, label: str) -> JsonDict:
    value = doc.get(key)
    if not isinstance(value, dict) or not value:
        raise ValueError(f"{label}.{key} is required and must be a non-empty object")
    return dict(value)


def require_list(doc: Mapping[str, Any], key: str, *, label: str) -> List[Any]:
    value = doc.get(key)
    if not isinstance(value, list) or not value:
        raise ValueError(f"{label}.{key} is required and must be a non-empty list")
    return list(value)


def require_keys(doc: Mapping[str, Any], keys: Sequence[str], *, label: str) -> None:
    missing = [k for k in keys if k not in doc or doc.get(k) in (None, "", [], {})]
    if missing:
        raise ValueError(f"{label} missing required keys: {', '.join(missing)}")


def get_nested(doc: Mapping[str, Any], path: Sequence[str], default: Any = None) -> Any:
    cur: Any = doc
    for part in path:
        if not isinstance(cur, Mapping):
            return default
        cur = cur.get(part)
        if cur is None:
            return default
    return cur


def scene_from_department_packet(scene_department_packet: Mapping[str, Any]) -> JsonDict:
    scene = scene_department_packet.get("scene")
    if isinstance(scene, dict) and scene:
        return dict(scene)
    # tolerate older packets that are themselves scene objects
    if scene_department_packet.get("scene_id"):
        return dict(scene_department_packet)
    raise ValueError("scene_department_packet must contain a non-empty 'scene' object or be a scene object")


def required_ids_from_scene_packet(scene_department_packet: Mapping[str, Any]) -> JsonDict:
    scene = scene_from_department_packet(scene_department_packet)
    continuity = scene_department_packet.get("continuity_check") if isinstance(scene_department_packet.get("continuity_check"), dict) else {}

    cast_ids = list_ids(scene.get("cast"), "character_id", "id", "name")
    costume_ids = list_ids(scene.get("wardrobe"), "costume_id", "default_costume_id", "costume_entry_id")
    if not costume_ids:
        costume_ids = list_ids(scene_department_packet.get("required_costumes"), "default_costume_id", "costume_id", "costume_entry_id")
    prop_ids = list_ids(scene.get("props"), "prop_id", "id", "name")
    hero_prop_ids = list_ids(
        [p for p in as_list(scene.get("props")) if isinstance(p, Mapping) and bool(p.get("story_critical"))],
        "prop_id",
        "id",
        "name",
    )

    return {
        "scene_id": nonempty_str(scene.get("scene_id")),
        "script_version_id": nonempty_str(scene.get("script_version_id")),
        "scene_number": nonempty_str(scene.get("scene_number")),
        "source_scope_ids": dedupe(as_list(scene.get("source_scope_ids")) + as_list(continuity.get("source_scope_ids"))),
        "required_canon_fact_ids": dedupe(as_list(scene.get("canon_fact_ids")) + as_list(continuity.get("canon_fact_ids"))),
        "required_character_ids": dedupe(cast_ids + as_list(continuity.get("required_cast_ids"))),
        "required_costume_ids": dedupe(costume_ids + as_list(continuity.get("required_costume_ids"))),
        "required_prop_ids": dedupe(prop_ids + as_list(continuity.get("required_prop_ids"))),
        "required_hero_prop_ids": hero_prop_ids,
        "required_location_id": nonempty_str(scene.get("location_id") or continuity.get("required_location_id")),
        "time_of_day": nonempty_str(scene.get("time_of_day")),
        "weather": nonempty_str(scene.get("weather")),
    }


def summarize_scene_department_packet(scene_department_packet: Mapping[str, Any]) -> JsonDict:
    scene = scene_from_department_packet(scene_department_packet)
    required = required_ids_from_scene_packet(scene_department_packet)
    color_plan = scene_department_packet.get("color_plan") if isinstance(scene_department_packet.get("color_plan"), dict) else {}
    location_design = scene_department_packet.get("location_design") if isinstance(scene_department_packet.get("location_design"), dict) else {}
    soundscape = scene_department_packet.get("soundscape") if isinstance(scene_department_packet.get("soundscape"), dict) else {}
    downstream = scene_department_packet.get("downstream_contract") if isinstance(scene_department_packet.get("downstream_contract"), dict) else {}
    director = scene_department_packet.get("director_vision") if isinstance(scene_department_packet.get("director_vision"), dict) else {}
    return {
        **required,
        "slugline": nonempty_str(scene.get("slugline")),
        "dramatic_function": nonempty_str(scene.get("dramatic_function")),
        "emotional_turn": nonempty_str(scene.get("emotional_turn")),
        "location_name": nonempty_str(scene.get("location_name") or location_design.get("name")),
        "set_dressing": dedupe(as_list(scene.get("set_dressing")) + as_list(location_design.get("set_dressing"))),
        "background_identity_markers": dedupe(
            as_list(location_design.get("texture_language")) + as_list(get_nested(downstream, ["camera", "location_identity_markers"], []))
        ),
        "palette": dedupe(as_list(color_plan.get("palette")) + as_list(location_design.get("palette"))),
        "lighting_intent": nonempty_str(color_plan.get("lighting_intent")),
        "vfx": as_list(scene.get("vfx")),
        "sound": as_list(scene.get("sound")) or as_list(soundscape.get("required_cues")),
        "music": scene.get("music") if isinstance(scene.get("music"), dict) else {},
        "director_do_not": as_list(director.get("do_not")),
        "audiobook_notes": as_list(scene.get("audiobook_notes")),
        "comic_motion_notes": as_list(scene.get("comic_motion_notes")),
        "podcast_notes": as_list(scene.get("podcast_notes")),
    }


def by_id(items: Any, *candidate_keys: str) -> Dict[str, JsonDict]:
    out: Dict[str, JsonDict] = {}
    for item in as_list(items):
        if not isinstance(item, Mapping):
            continue
        for key in candidate_keys:
            v = item.get(key)
            if isinstance(v, str) and v.strip():
                out[v.strip()] = dict(item)
                break
    return out


def find_scene_in_camera_script(camera_script: Mapping[str, Any], scene_id: str) -> JsonDict:
    scenes = as_list(camera_script.get("scenes"))
    if not scenes and camera_script.get("shots"):
        return {"scene_id": scene_id, "shots": as_list(camera_script.get("shots"))}
    for scene in scenes:
        if isinstance(scene, Mapping) and str(scene.get("scene_id") or "").strip() == scene_id:
            return dict(scene)
    if len(scenes) == 1 and isinstance(scenes[0], Mapping):
        return dict(scenes[0])
    raise ValueError(f"camera_script does not contain scene_id={scene_id!r}")


def hard_vfx_ids(scene_department_packet: Mapping[str, Any]) -> List[str]:
    scene = scene_from_department_packet(scene_department_packet)
    out = []
    for fx in as_list(scene.get("vfx")):
        if isinstance(fx, Mapping) and str(fx.get("priority") or "").lower() == "hard":
            out.append(nonempty_str(fx.get("effect_id") or fx.get("id") or fx.get("description")))
    return dedupe([x for x in out if x])


def line_class_to_audio_bus(line_class: str, output_mode: str = "audiobook") -> str:
    lc = nonempty_str(line_class).lower()
    if lc in {"onscreen_dialogue", "dialogue", "character_dialogue"}:
        return "DX_ONSCREEN"
    if lc in {"offscreen_dialogue", "os_dialogue"}:
        return "DX_OFFSCREEN"
    if lc in {"voice_over", "narrator_bridge", "internal_voice_over", "narration"}:
        return "VO" if output_mode != "video" else "VO_OPTIONAL"
    if lc in {"group_walla", "walla"}:
        return "WALLA"
    if lc in {"ambience_cue", "ambience"}:
        return "AMB"
    if lc in {"music_cue", "music"}:
        return "MX"
    if lc in {"silent_action", "reaction_beat", "transition_bridge"}:
        return "FX"
    return "DX_ONSCREEN"


def join_prompt_lines(lines: Iterable[Any]) -> str:
    normalized = [nonempty_str(x) for x in lines if nonempty_str(x)]
    return "\n".join(f"- {x}" for x in dedupe(normalized))
