from __future__ import annotations

from typing import Any, Dict, List, Mapping, Optional

from boock.render_contracts.common import (
    JsonDict,
    as_list,
    dedupe,
    line_class_to_audio_bus,
    nonempty_str,
    required_ids_from_scene_packet,
    scene_from_department_packet,
    stable_id,
    summarize_scene_department_packet,
)


def _timeline_segments(performance_timeline: Mapping[str, Any]) -> List[JsonDict]:
    for key in ("segments", "events", "timeline", "lines", "beats"):
        value = performance_timeline.get(key)
        if isinstance(value, list) and value:
            return [dict(x) for x in value if isinstance(x, Mapping)]
    scenes = as_list(performance_timeline.get("scenes"))
    out: List[JsonDict] = []
    for scene in scenes:
        if not isinstance(scene, Mapping):
            continue
        for seg in as_list(scene.get("segments") or scene.get("beats") or scene.get("lines")):
            if isinstance(seg, Mapping):
                row = dict(seg)
                row.setdefault("scene_id", scene.get("scene_id", ""))
                out.append(row)
    return out


def _stem_rules(stem_plan: Mapping[str, Any]) -> List[JsonDict]:
    for key in ("stems", "stem_buses", "buses", "lanes"):
        value = stem_plan.get(key)
        if isinstance(value, list) and value:
            return [dict(x) for x in value if isinstance(x, Mapping)]
    return [
        {"bus": "DX_ONSCREEN", "kind": "dialogue", "required": True},
        {"bus": "DX_OFFSCREEN", "kind": "dialogue", "required": False},
        {"bus": "VO", "kind": "narration", "required": False},
        {"bus": "VO_OPTIONAL", "kind": "narration", "required": False},
        {"bus": "FOLEY", "kind": "foley", "required": False},
        {"bus": "AMB", "kind": "ambience", "required": False},
        {"bus": "MX", "kind": "music", "required": False},
        {"bus": "WALLA", "kind": "walla", "required": False},
        {"bus": "FX", "kind": "effects", "required": False},
    ]


def build_cinematic_audio_render_contract(
    *,
    book_version_id: str,
    variant_id: str,
    chapter_id: str,
    performance_timeline: Mapping[str, Any],
    stem_plan: Mapping[str, Any],
    audio_design_packet: Optional[Mapping[str, Any]] = None,
    scene_department_packet: Optional[Mapping[str, Any]] = None,
    output_mode: str = "audiobook",
    strict: bool = True,
) -> JsonDict:
    """Require performance timeline + stem plan for cinematic audiobook/video audio."""
    if strict and not performance_timeline:
        raise ValueError("performance_timeline is mandatory for cinematic audio")
    if strict and not stem_plan:
        raise ValueError("stem_plan is mandatory for cinematic audio")

    segments = _timeline_segments(performance_timeline)
    if strict and not segments:
        raise ValueError("performance_timeline must contain segments/events/lines")
    stems = _stem_rules(stem_plan)

    scene_summary: JsonDict = {}
    required: JsonDict = {}
    if scene_department_packet:
        scene_summary = summarize_scene_department_packet(scene_department_packet)
        required = required_ids_from_scene_packet(scene_department_packet)
    audio_design_packet = audio_design_packet or {}

    soundscape = audio_design_packet.get("soundscape") if isinstance(audio_design_packet.get("soundscape"), dict) else scene_summary.get("soundscape") if isinstance(scene_summary.get("soundscape"), dict) else {}
    required_foley = as_list(audio_design_packet.get("required_foley")) or [
        nonempty_str(x.get("description") if isinstance(x, Mapping) else x)
        for x in as_list(scene_summary.get("sound"))
        if nonempty_str(x.get("description") if isinstance(x, Mapping) else x)
    ]
    mix_mode = "cinematic_audiobook" if output_mode == "audiobook" else "video_film_mix"
    segment_rows: List[JsonDict] = []
    for idx, seg in enumerate(segments, start=1):
        line_class = nonempty_str(seg.get("line_class") or seg.get("type") or "onscreen_dialogue")
        bus = nonempty_str(seg.get("stem_bus") or line_class_to_audio_bus(line_class, output_mode))
        if output_mode == "video" and bus == "VO_OPTIONAL" and not bool(seg.get("explicit_video_vo")):
            include_in_mix = False
        else:
            include_in_mix = not (output_mode == "video" and line_class == "narrator_bridge" and not bool(seg.get("explicit_video_vo")))
        segment_rows.append(
            {
                "segment_id": nonempty_str(seg.get("segment_id"), f"seg_{idx:04d}"),
                "scene_id": nonempty_str(seg.get("scene_id") or required.get("scene_id", "")),
                "beat_id": nonempty_str(seg.get("beat_id")),
                "line_id": nonempty_str(seg.get("line_id")),
                "speaker_id": nonempty_str(seg.get("speaker_id") or seg.get("speaker")),
                "line_class": line_class,
                "text": nonempty_str(seg.get("text")),
                "start_s": float(seg.get("start_s") or 0.0),
                "end_s": float(seg.get("end_s") or 0.0),
                "duration_s": float(seg.get("duration_s") or max(0.0, float(seg.get("end_s") or 0.0) - float(seg.get("start_s") or 0.0))),
                "emotion": nonempty_str(seg.get("emotion")),
                "subtext": nonempty_str(seg.get("subtext")),
                "performance_note": nonempty_str(seg.get("performance_note") or seg.get("performance_cue")),
                "mic_distance": nonempty_str(seg.get("mic_distance") or (seg.get("spatial", {}).get("mic_distance") if isinstance(seg.get("spatial"), dict) else "")),
                "spatial_position": seg.get("spatial_position") or (seg.get("spatial") if isinstance(seg.get("spatial"), dict) else {}),
                "pause_before_ms": int(seg.get("pause_before_ms") or 0),
                "pause_after_ms": int(seg.get("pause_after_ms") or 0),
                "overlap_policy": nonempty_str(seg.get("overlap_policy") or ("allow_overlap" if seg.get("allow_overlap_with_next") else "no_overlap")),
                "stem_bus": bus,
                "include_in_audiobook_mix": output_mode == "audiobook" or include_in_mix,
                "include_in_video_mix": output_mode == "video" and include_in_mix,
                "requires_lipsync": output_mode == "video" and line_class in {"onscreen_dialogue", "dialogue", "character_dialogue"},
                "source": dict(seg),
            }
        )

    bus_counts: Dict[str, int] = {}
    for row in segment_rows:
        bus_counts[row["stem_bus"]] = bus_counts.get(row["stem_bus"], 0) + 1

    contract_id = stable_id("cinematic_audio_render_contract", book_version_id, variant_id, chapter_id, output_mode, performance_timeline.get("performance_timeline_id") or performance_timeline.get("adaptation_performance_timeline_id"), stem_plan.get("stem_plan_id") or stem_plan.get("adaptation_stem_plan_id"))
    return {
        "artifact_type": "cinematic_audio_render_contract",
        "version": "0.1.0",
        "cinematic_audio_render_contract_id": contract_id,
        "book_version_id": book_version_id,
        "variant_id": variant_id,
        "chapter_id": chapter_id,
        "output_mode": output_mode,
        "mix_mode": mix_mode,
        "performance_timeline_id": performance_timeline.get("performance_timeline_id") or performance_timeline.get("adaptation_performance_timeline_id", ""),
        "stem_plan_id": stem_plan.get("stem_plan_id") or stem_plan.get("adaptation_stem_plan_id", ""),
        "scene_department_packet_id": (scene_department_packet or {}).get("scene_department_packet_id", ""),
        "audio_design_packet_id": audio_design_packet.get("audio_design_packet_id", ""),
        "source_scope_ids": required.get("source_scope_ids", []),
        "required_canon_fact_ids": required.get("required_canon_fact_ids", []),
        "required_speaker_ids": dedupe([row["speaker_id"] for row in segment_rows if row["speaker_id"]]),
        "required_stem_buses": dedupe([row["stem_bus"] for row in segment_rows] + [nonempty_str(s.get("bus")) for s in stems if nonempty_str(s.get("bus")) and s.get("required")]),
        "stem_buses": stems,
        "segments": segment_rows,
        "soundscape": {
            "soundscape_id": audio_design_packet.get("soundscape_id") or soundscape.get("soundscape_id", ""),
            "location_id": audio_design_packet.get("location_id") or soundscape.get("location_id") or required.get("required_location_id", ""),
            "base_bed": audio_design_packet.get("base_bed") or soundscape.get("base_bed", ""),
            "required_foley": dedupe([x for x in required_foley if x]),
            "music_mood": audio_design_packet.get("music_mood") or (scene_summary.get("music") or {}).get("mood", ""),
            "narrator_bridge_policy": audio_design_packet.get("narrator_bridge_policy", "sparse_bridge_only_when_needed"),
        },
        "mix_policy": {
            "share_timed_stems_not_final_mix": True,
            "audiobook": {
                "include_buses": ["DX_ONSCREEN", "DX_OFFSCREEN", "VO", "WALLA", "FOLEY", "FX", "AMB", "MX"],
                "dialogue_priority": "highest",
                "music_ducking": True,
            },
            "video": {
                "include_buses": ["DX_ONSCREEN", "DX_OFFSCREEN", "WALLA", "FOLEY", "FX", "AMB", "MX"],
                "optional_vo_bus": "VO_OPTIONAL",
                "exclude_narrator_bridge_by_default": True,
            },
        },
        "summary": {
            "segment_count": len(segment_rows),
            "bus_counts": bus_counts,
            "speaker_count": len(dedupe([row["speaker_id"] for row in segment_rows if row["speaker_id"]])),
        },
        "provenance": {"generator": "build_cinematic_audio_render_contract_v1"},
    }


def explode_cinematic_audio_contract_to_chunks(
    *,
    cinematic_audio_render_contract: Mapping[str, Any],
    max_segments_per_chunk: int = 12,
) -> JsonDict:
    segments = [dict(x) for x in as_list(cinematic_audio_render_contract.get("segments")) if isinstance(x, Mapping)]
    chunks = []
    for idx in range(0, len(segments), max_segments_per_chunk):
        chunk_segments = segments[idx : idx + max_segments_per_chunk]
        chunk_id = f"audio_chunk_{idx // max_segments_per_chunk + 1:04d}"
        chunks.append(
            {
                "chunk_id": chunk_id,
                "segment_ids": [s.get("segment_id") for s in chunk_segments],
                "segments": chunk_segments,
                "required_stem_buses": dedupe([s.get("stem_bus") for s in chunk_segments]),
            }
        )
    return {
        "artifact_type": "cinematic_audio_chunk_manifest",
        "version": "0.1.0",
        "cinematic_audio_chunk_manifest_id": stable_id("cinematic_audio_chunk_manifest", cinematic_audio_render_contract.get("cinematic_audio_render_contract_id"), max_segments_per_chunk),
        "source_contract_id": cinematic_audio_render_contract.get("cinematic_audio_render_contract_id", ""),
        "chunks": chunks,
        "summary": {"chunk_count": len(chunks), "segment_count": len(segments)},
        "provenance": {"generator": "explode_cinematic_audio_contract_to_chunks_v1"},
    }
