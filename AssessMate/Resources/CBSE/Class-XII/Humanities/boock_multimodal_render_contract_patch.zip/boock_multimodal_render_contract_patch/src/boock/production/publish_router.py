from __future__ import annotations

from typing import Any, Dict, List, Mapping, Optional

from boock.render_contracts.common import JsonDict, as_list, dedupe, nonempty_str, stable_id


_CATEGORY_TO_STEP = {
    "missing_hero_prop": "generate_prop_layer_or_rerender_shot",
    "missing_prop": "generate_prop_layer_or_rerender_shot",
    "wrong_prop": "generate_prop_layer_or_rerender_shot",
    "missing_costume": "rerender_visual_asset_with_costume_bible",
    "wrong_costume": "rerender_visual_asset_with_costume_bible",
    "missing_character": "rerender_visual_asset_with_character_reference_lock",
    "wrong_character": "rerender_visual_asset_with_character_reference_lock",
    "wrong_location": "rerender_scene_with_location_bible",
    "missing_location": "rerender_scene_with_location_bible",
    "missing_set_dressing": "rerender_scene_with_location_bible",
    "missing_hard_vfx": "run_vfx_overlay_pass",
    "missing_audio_speaker": "rerender_dialogue_stem_from_performance_timeline",
    "missing_sound_cue": "patch_sound_plan_or_stem_manifest",
    "missing_foley": "patch_sound_plan_or_stem_manifest",
    "missing_music_motif": "patch_music_stem_or_mix_recipe",
    "motion_comic_missing_layer": "regenerate_motion_comic_layers",
    "motion_comic_missing_cleanplate": "regenerate_motion_comic_layers",
    "low_audio_qc": "repair_audio_from_qc",
    "canon_violation": "rerun_upstream_canon_contract_generation",
}


def _state(report: Mapping[str, Any]) -> str:
    return nonempty_str(report.get("state") or report.get("status") or report.get("gate_state") or "unknown").lower()


def _issues(report: Mapping[str, Any]) -> List[JsonDict]:
    for key in ("issues", "findings", "violations", "validation_issues"):
        value = report.get(key)
        if isinstance(value, list):
            return [dict(x) if isinstance(x, Mapping) else {"message": str(x)} for x in value]
    # tolerate previous schema shape: report["scenes"][].issues
    out: List[JsonDict] = []
    for scene in as_list(report.get("scenes")):
        if isinstance(scene, Mapping):
            for issue in as_list(scene.get("issues")):
                if isinstance(issue, Mapping):
                    row = dict(issue)
                else:
                    row = {"message": str(issue)}
                row.setdefault("scene_id", scene.get("scene_id", ""))
                out.append(row)
    return out


def enforce_multimodal_continuity_publish_gate(
    *,
    publish_manifest: Mapping[str, Any],
    continuity_report: Mapping[str, Any],
    strict: bool = True,
) -> JsonDict:
    state = _state(continuity_report)
    issues = _issues(continuity_report)
    blockers = [
        i for i in issues
        if nonempty_str(i.get("severity") or i.get("level")).lower() in {"blocker", "blocked", "critical"}
        or nonempty_str(i.get("category")).lower() in {"missing_hero_prop", "canon_violation"}
    ]
    repairable = [
        i for i in issues
        if nonempty_str(i.get("severity") or i.get("level")).lower() in {"repair", "needs_repair", "error", "warning"}
    ]

    if state in {"passed", "pass"} and not blockers:
        gate_state = "publish_allowed"
    elif state in {"passed_with_warnings", "warning", "warnings"} and not blockers and not strict:
        gate_state = "publish_allowed_with_warnings"
    elif blockers:
        gate_state = "blocked_by_production_continuity"
    else:
        gate_state = "needs_targeted_repair"

    gated_id = stable_id("gated_publish_manifest", publish_manifest.get("publish_manifest_id") or publish_manifest.get("artifact_id"), continuity_report.get("production_continuity_validation_report_id") or continuity_report.get("report_id"), gate_state)
    out = dict(publish_manifest)
    out.update(
        {
            "artifact_type": "gated_publish_manifest",
            "gated_publish_manifest_id": gated_id,
            "publish_gate_state": gate_state,
            "continuity_report_id": continuity_report.get("production_continuity_validation_report_id") or continuity_report.get("report_id", ""),
            "continuity_state": state,
            "blocker_count": len(blockers),
            "repairable_issue_count": len(repairable),
            "can_publish": gate_state in {"publish_allowed", "publish_allowed_with_warnings"},
            "blocked_reason": "" if gate_state in {"publish_allowed", "publish_allowed_with_warnings"} else "production_continuity_validation_failed",
            "provenance": {
                **(publish_manifest.get("provenance") if isinstance(publish_manifest.get("provenance"), dict) else {}),
                "gate_generator": "enforce_multimodal_continuity_publish_gate_v1",
            },
        }
    )
    return out


def route_continuity_repair_tickets(
    *,
    continuity_report: Mapping[str, Any],
    repair_ticket_manifest: Optional[Mapping[str, Any]] = None,
    pipeline_artifacts: Optional[Mapping[str, Any]] = None,
    max_auto_repair_attempts: int = 2,
) -> JsonDict:
    issues = _issues(continuity_report)
    manifest_tickets = as_list((repair_ticket_manifest or {}).get("tickets") or (repair_ticket_manifest or {}).get("repair_tickets"))
    ticket_rows: List[JsonDict] = []
    for issue in issues:
        category = nonempty_str(issue.get("category") or issue.get("issue_type") or issue.get("type") or "unknown").lower()
        severity = nonempty_str(issue.get("severity") or issue.get("level") or "repair").lower()
        if severity in {"info", "note"}:
            continue
        target_step = _CATEGORY_TO_STEP.get(category, "manual_review_or_custom_repair")
        target_modality = nonempty_str(issue.get("modality") or issue.get("asset_modality") or _infer_modality(category))
        scene_id = nonempty_str(issue.get("scene_id"))
        shot_id = nonempty_str(issue.get("shot_id"))
        panel_id = nonempty_str(issue.get("panel_id"))
        audio_segment_id = nonempty_str(issue.get("segment_id") or issue.get("audio_segment_id"))
        ticket_rows.append(
            {
                "repair_ticket_id": stable_id("repair_ticket", continuity_report.get("production_continuity_validation_report_id") or continuity_report.get("report_id"), category, scene_id, shot_id, panel_id, audio_segment_id, issue.get("message")),
                "category": category,
                "severity": severity,
                "target_modality": target_modality,
                "target_step": target_step,
                "scene_id": scene_id,
                "shot_id": shot_id,
                "panel_id": panel_id,
                "audio_segment_id": audio_segment_id,
                "required_inputs": _required_inputs_for_step(target_step),
                "do_not_rerun": _do_not_rerun_for_step(target_step),
                "issue": dict(issue),
            }
        )

    # Merge explicit tickets that may already exist from the continuity validator.
    for ticket in manifest_tickets:
        if not isinstance(ticket, Mapping):
            continue
        category = nonempty_str(ticket.get("category") or ticket.get("issue_type") or "unknown").lower()
        target_step = nonempty_str(ticket.get("target_step") or _CATEGORY_TO_STEP.get(category) or "manual_review_or_custom_repair")
        row = dict(ticket)
        row.setdefault("repair_ticket_id", stable_id("repair_ticket", row.get("scene_id"), row.get("shot_id"), category, row.get("message")))
        row.setdefault("target_step", target_step)
        row.setdefault("required_inputs", _required_inputs_for_step(target_step))
        row.setdefault("do_not_rerun", _do_not_rerun_for_step(target_step))
        ticket_rows.append(row)

    # De-dupe by repair_ticket_id and group by step.
    unique: Dict[str, JsonDict] = {}
    for t in ticket_rows:
        unique[str(t["repair_ticket_id"])] = t
    ticket_rows = list(unique.values())
    route_groups: Dict[str, List[str]] = {}
    for t in ticket_rows:
        route_groups.setdefault(str(t["target_step"]), []).append(str(t["repair_ticket_id"]))

    auto_rerun_order = [
        "rerender_visual_asset_with_character_reference_lock",
        "rerender_visual_asset_with_costume_bible",
        "generate_prop_layer_or_rerender_shot",
        "rerender_scene_with_location_bible",
        "run_vfx_overlay_pass",
        "regenerate_motion_comic_layers",
        "rerender_dialogue_stem_from_performance_timeline",
        "patch_sound_plan_or_stem_manifest",
        "patch_music_stem_or_mix_recipe",
        "repair_audio_from_qc",
        "build_production_continuity_validation_report",
        "apply_production_continuity_publish_gate",
    ]
    active_order = [step for step in auto_rerun_order if step in route_groups]
    return {
        "artifact_type": "continuity_repair_route_plan",
        "version": "0.1.0",
        "continuity_repair_route_plan_id": stable_id("continuity_repair_route_plan", continuity_report.get("production_continuity_validation_report_id") or continuity_report.get("report_id"), len(ticket_rows)),
        "continuity_report_id": continuity_report.get("production_continuity_validation_report_id") or continuity_report.get("report_id", ""),
        "repair_ticket_manifest_id": (repair_ticket_manifest or {}).get("continuity_repair_ticket_manifest_id", ""),
        "tickets": ticket_rows,
        "route_groups": route_groups,
        "auto_rerun_order": active_order,
        "manual_review_ticket_ids": [t["repair_ticket_id"] for t in ticket_rows if t.get("target_step") == "manual_review_or_custom_repair" or nonempty_str(t.get("severity")).lower() in {"blocker", "critical"}],
        "max_auto_repair_attempts": max_auto_repair_attempts,
        "pipeline_artifact_hints": dict(pipeline_artifacts or {}),
        "provenance": {"generator": "route_continuity_repair_tickets_v1"},
        "summary": {
            "ticket_count": len(ticket_rows),
            "auto_route_count": sum(1 for t in ticket_rows if t.get("target_step") != "manual_review_or_custom_repair"),
            "manual_review_count": sum(1 for t in ticket_rows if t.get("target_step") == "manual_review_or_custom_repair"),
        },
    }


def _infer_modality(category: str) -> str:
    if category.startswith("missing_audio") or category in {"missing_sound_cue", "missing_foley", "missing_music_motif", "low_audio_qc"}:
        return "audio"
    if category.startswith("motion_comic"):
        return "motion_comic"
    if "prop" in category or "costume" in category or "location" in category or "vfx" in category or "character" in category:
        return "visual"
    return "multimodal"


def _required_inputs_for_step(step: str) -> List[str]:
    mapping = {
        "rerender_visual_asset_with_character_reference_lock": ["image_render_context_pack", "reference_lock_manifest", "character_reference_sheet"],
        "rerender_visual_asset_with_costume_bible": ["image_render_context_pack", "reference_lock_manifest", "costume_bible"],
        "generate_prop_layer_or_rerender_shot": ["image_render_context_pack", "prop_bible", "shot_or_panel_id"],
        "rerender_scene_with_location_bible": ["scene_department_packet", "location_bible", "production_design_bible"],
        "run_vfx_overlay_pass": ["shot_or_panel_asset", "vfx_creature_bible", "required_hard_vfx_ids"],
        "regenerate_motion_comic_layers": ["motion_comic_storyboard_plan", "motion_comic_panel_render_manifest", "segmented_character_layer_manifest"],
        "rerender_dialogue_stem_from_performance_timeline": ["performance_timeline", "cinematic_audio_render_contract"],
        "patch_sound_plan_or_stem_manifest": ["audio_design_packet", "cinematic_audio_render_contract", "stem_plan"],
        "patch_music_stem_or_mix_recipe": ["audio_design_packet", "music_motif_ids", "mix_recipe"],
        "repair_audio_from_qc": ["audio_qc", "audio_mix_recipe", "chapter_audio_stem_manifest"],
        "rerun_upstream_canon_contract_generation": ["canon_ledger", "multimodal_generation_contract", "ams"],
    }
    return mapping.get(step, ["continuity_report", "failed_asset_metadata"])


def _do_not_rerun_for_step(step: str) -> List[str]:
    if step in {"rerender_visual_asset_with_character_reference_lock", "rerender_visual_asset_with_costume_bible", "generate_prop_layer_or_rerender_shot", "rerender_scene_with_location_bible", "run_vfx_overlay_pass"}:
        return ["rewrite_chapter", "generate_adaptation_master_script", "build_screenwriter_beat_sheet", "render_dialogue_stems"]
    if step in {"rerender_dialogue_stem_from_performance_timeline", "patch_sound_plan_or_stem_manifest", "patch_music_stem_or_mix_recipe", "repair_audio_from_qc"}:
        return ["rewrite_chapter", "generate_adaptation_master_script", "render_video_shots", "render_motion_comic_layers"]
    if step == "regenerate_motion_comic_layers":
        return ["rewrite_chapter", "generate_adaptation_master_script", "render_dialogue_stems"]
    return []
