from __future__ import annotations

from typing import Any, Dict, List, Mapping, Optional

from boock.render_contracts.common import (
    JsonDict,
    as_list,
    dedupe,
    find_scene_in_camera_script,
    hard_vfx_ids,
    join_prompt_lines,
    nonempty_str,
    required_ids_from_scene_packet,
    scene_from_department_packet,
    stable_id,
    summarize_scene_department_packet,
)


def _wardrobe_for_character(scene: Mapping[str, Any], character_id: str) -> str:
    for w in as_list(scene.get("wardrobe")):
        if isinstance(w, Mapping) and nonempty_str(w.get("character_id")) == character_id:
            return nonempty_str(w.get("costume_id") or w.get("default_costume_id") or w.get("costume_entry_id"))
    return ""


def _shot_prop_ids(shot: Mapping[str, Any], scene_required_hero_prop_ids: List[str]) -> List[str]:
    meta = shot.get("metadata") if isinstance(shot.get("metadata"), dict) else shot.get("meta") if isinstance(shot.get("meta"), dict) else {}
    prop_ids = []
    for p in as_list(meta.get("prop_interactions")):
        if isinstance(p, Mapping) and nonempty_str(p.get("prop_id")):
            prop_ids.append(nonempty_str(p.get("prop_id")))
    for sid in as_list(shot.get("subject_ids")):
        if isinstance(sid, str) and sid in scene_required_hero_prop_ids:
            prop_ids.append(sid)
    if str(shot.get("coverage_role") or "").lower() in {"prop_insert", "insert"}:
        prop_ids.extend(scene_required_hero_prop_ids)
    return dedupe(prop_ids)


def compile_cinematic_shot_timeline_from_camera_script(
    *,
    book_version_id: str,
    variant_id: str,
    chapter_id: str,
    camera_script: Mapping[str, Any],
    scene_department_packet: Mapping[str, Any],
    reference_lock_manifest: Optional[Mapping[str, Any]] = None,
    strict: bool = True,
) -> JsonDict:
    """Compile a video shot timeline only from camera_script + scene_department_packet.

    This intentionally rejects raw-prose-only video generation. The goal is to force the
    renderer to use Hollywood-style camera and department contracts.
    """
    if strict and not camera_script:
        raise ValueError("camera_script is mandatory for cinematic video shot timeline")
    if strict and not scene_department_packet:
        raise ValueError("scene_department_packet is mandatory for cinematic video shot timeline")

    scene = scene_from_department_packet(scene_department_packet)
    required = required_ids_from_scene_packet(scene_department_packet)
    summary = summarize_scene_department_packet(scene_department_packet)
    camera_scene = find_scene_in_camera_script(camera_script, required["scene_id"])
    camera_shots = as_list(camera_scene.get("shots"))
    if strict and not camera_shots:
        raise ValueError(f"camera_script scene {required['scene_id']} has no shots")

    shot_rows: List[JsonDict] = []
    warnings: List[str] = []
    for idx, sh in enumerate(camera_shots, start=1):
        if not isinstance(sh, Mapping):
            continue
        shot_id = nonempty_str(sh.get("shot_id"), f"{required['scene_id']}.shot.{idx:04d}")
        subject_ids = [nonempty_str(x) for x in as_list(sh.get("subject_ids")) if nonempty_str(x)]
        character_subjects = [x for x in subject_ids if x in required["required_character_ids"]]
        prop_ids = _shot_prop_ids(sh, required["required_hero_prop_ids"])
        if not character_subjects and str(sh.get("coverage_role") or "").lower() in {"primary_dialogue", "dialogue_coverage"}:
            warnings.append(f"{shot_id}: dialogue coverage has no known character subject")

        dialogue_anchor = sh.get("dialogue_anchor") if isinstance(sh.get("dialogue_anchor"), dict) else {}
        line_class = nonempty_str(dialogue_anchor.get("line_class") or sh.get("line_class") or "silent_action")
        speaker = nonempty_str(dialogue_anchor.get("speaker") or sh.get("speaker"))
        is_dialogue = line_class in {"onscreen_dialogue", "dialogue", "character_dialogue"}
        editorial_lock = bool(sh.get("editorial_lock") or (line_class in {"voice_over", "narrator_bridge", "offscreen_dialogue"}))
        lipsync_target_id = speaker if is_dialogue and bool(dialogue_anchor.get("onscreen", True)) else ""

        costume_ids = dedupe([_wardrobe_for_character(scene, cid) for cid in character_subjects if _wardrobe_for_character(scene, cid)])
        if not costume_ids and character_subjects:
            costume_ids = required["required_costume_ids"]

        shot_rows.append(
            {
                "shot_id": shot_id,
                "scene_id": required["scene_id"],
                "beat_id": nonempty_str(sh.get("beat_id")),
                "blocking_beat_id": nonempty_str(sh.get("blocking_beat_id")),
                "ordinal": int(sh.get("ordinal") or idx),
                "duration_target_s": float(sh.get("duration_target_s") or 2.0),
                "render_mode": nonempty_str(sh.get("render_mode") or "contracted_shot"),
                "coverage_role": nonempty_str(sh.get("coverage_role")),
                "shot_size": nonempty_str(sh.get("shot_size") or sh.get("shot_type")),
                "angle": nonempty_str(sh.get("angle")),
                "camera_move": nonempty_str(sh.get("camera_move") or sh.get("movement")),
                "subject_ids": subject_ids,
                "required_character_ids": character_subjects,
                "required_costume_ids": costume_ids,
                "required_prop_ids": prop_ids,
                "required_hero_prop_ids": [pid for pid in prop_ids if pid in required["required_hero_prop_ids"]],
                "required_location_id": required["required_location_id"],
                "required_time_of_day": required["time_of_day"],
                "required_weather": required["weather"],
                "required_hard_vfx_ids": hard_vfx_ids(scene_department_packet),
                "source_scope_ids": required["source_scope_ids"],
                "required_canon_fact_ids": dedupe(required["required_canon_fact_ids"] + as_list(sh.get("required_canon_fact_ids"))),
                "required_department_entry_ids": as_list((reference_lock_manifest or {}).get("required_lock_ids")),
                "dialogue_anchor": dict(dialogue_anchor),
                "line_class": line_class,
                "speaker": speaker,
                "lipsync_target_id": lipsync_target_id,
                "audio_sync": "lipsync" if lipsync_target_id else ("voiceover_or_cutaway" if line_class in {"voice_over", "narrator_bridge", "offscreen_dialogue"} else "none"),
                "editorial_lock": editorial_lock,
                "meta": {
                    "speaker_role": "character" if lipsync_target_id else "offscreen",
                    "preferred_render_policy": "talking_head" if lipsync_target_id else "cutaway_detail",
                    "location_identity_markers": summary.get("background_identity_markers"),
                    "palette": summary.get("palette"),
                    "lighting_intent": summary.get("lighting_intent"),
                    "set_dressing": summary.get("set_dressing"),
                    "source_camera_shot": dict(sh),
                },
            }
        )

    timeline_id = stable_id("contracted_cinematic_shot_timeline", book_version_id, variant_id, chapter_id, required["scene_id"], camera_script.get("camera_script_id", ""))
    return {
        "artifact_type": "contracted_cinematic_shot_timeline",
        "version": "0.1.0",
        "contracted_cinematic_shot_timeline_id": timeline_id,
        "book_version_id": book_version_id,
        "variant_id": variant_id,
        "chapter_id": chapter_id,
        "script_version_id": required["script_version_id"],
        "scene_id": required["scene_id"],
        "camera_script_id": camera_script.get("camera_script_id", ""),
        "scene_department_packet_id": scene_department_packet.get("scene_department_packet_id", ""),
        "reference_lock_manifest_id": (reference_lock_manifest or {}).get("reference_lock_manifest_id", ""),
        "shots": shot_rows,
        "warnings": warnings,
        "provenance": {
            "generator": "compile_cinematic_shot_timeline_from_camera_script_v1",
            "policy": "camera_script_and_scene_department_packet_are_mandatory",
        },
        "summary": {
            "shot_count": len(shot_rows),
            "lipsync_shot_count": sum(1 for s in shot_rows if s.get("lipsync_target_id")),
            "cutaway_or_non_lipsync_count": sum(1 for s in shot_rows if not s.get("lipsync_target_id")),
            "required_location_id": required["required_location_id"],
        },
    }


def build_video_render_prompt_pack(
    *,
    contracted_shot_timeline: Mapping[str, Any],
    scene_department_packet: Mapping[str, Any],
    reference_lock_manifest: Optional[Mapping[str, Any]] = None,
) -> JsonDict:
    summary = summarize_scene_department_packet(scene_department_packet)
    required = required_ids_from_scene_packet(scene_department_packet)
    prompts: List[JsonDict] = []
    for sh in as_list(contracted_shot_timeline.get("shots")):
        if not isinstance(sh, Mapping):
            continue
        positive = [
            f"shot {sh.get('shot_id')} for scene {required['scene_id']}: {summary.get('dramatic_function')}",
            f"camera: {sh.get('shot_size')} {sh.get('angle')} {sh.get('camera_move')} / coverage {sh.get('coverage_role')}",
            f"subjects: {', '.join(as_list(sh.get('subject_ids')))}",
            f"costumes: {', '.join(as_list(sh.get('required_costume_ids')))}",
            f"hero props: {', '.join(as_list(sh.get('required_hero_prop_ids')))}",
            f"location: {required['required_location_id']} / markers: {', '.join(summary.get('background_identity_markers') or [])}",
            f"palette: {', '.join(summary.get('palette') or [])}; lighting: {summary.get('lighting_intent')}",
            f"time/weather: {required['time_of_day']} / {required['weather']}",
        ]
        negative = list(summary.get("director_do_not") or []) + [
            "do not change costumes or hero props",
            "do not change the required location, weather, or time of day",
            "do not make narrator/offscreen audio a lipsync target",
        ]
        prompts.append(
            {
                "shot_id": sh.get("shot_id", ""),
                "scene_id": sh.get("scene_id", ""),
                "beat_id": sh.get("beat_id", ""),
                "prompt": join_prompt_lines(positive),
                "negative_prompt": join_prompt_lines(negative),
                "required_validation_metadata": {
                    "required_character_ids": sh.get("required_character_ids", []),
                    "required_costume_ids": sh.get("required_costume_ids", []),
                    "required_prop_ids": sh.get("required_prop_ids", []),
                    "required_location_id": sh.get("required_location_id", ""),
                    "required_weather": sh.get("required_weather", ""),
                    "required_time_of_day": sh.get("required_time_of_day", ""),
                    "required_hard_vfx_ids": sh.get("required_hard_vfx_ids", []),
                    "lipsync_target_id": sh.get("lipsync_target_id", ""),
                    "audio_sync": sh.get("audio_sync", ""),
                    "editorial_lock": sh.get("editorial_lock", False),
                },
                "reference_lock_ids": sh.get("required_department_entry_ids", []),
            }
        )
    return {
        "artifact_type": "video_render_prompt_pack",
        "version": "0.1.0",
        "video_render_prompt_pack_id": stable_id("video_render_prompt_pack", contracted_shot_timeline.get("contracted_cinematic_shot_timeline_id"), reference_lock_manifest and reference_lock_manifest.get("reference_lock_manifest_id")),
        "contracted_cinematic_shot_timeline_id": contracted_shot_timeline.get("contracted_cinematic_shot_timeline_id", ""),
        "scene_department_packet_id": scene_department_packet.get("scene_department_packet_id", ""),
        "prompts": prompts,
        "summary": {"prompt_count": len(prompts)},
        "provenance": {"generator": "build_video_render_prompt_pack_v1"},
    }
