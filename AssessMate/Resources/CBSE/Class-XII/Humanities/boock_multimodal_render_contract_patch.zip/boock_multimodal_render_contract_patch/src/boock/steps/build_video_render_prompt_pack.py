from __future__ import annotations

from typing import Any, Dict

from boock.video.contracted_shots import build_video_render_prompt_pack


def run_build_video_render_prompt_pack(input_payload: Dict[str, Any]) -> Dict[str, Any]:
    pack = build_video_render_prompt_pack(
        contracted_shot_timeline=input_payload["contracted_cinematic_shot_timeline"],
        scene_department_packet=input_payload["scene_department_packet"],
        reference_lock_manifest=input_payload.get("reference_lock_manifest"),
    )
    return {**input_payload, "video_render_prompt_pack": pack}
