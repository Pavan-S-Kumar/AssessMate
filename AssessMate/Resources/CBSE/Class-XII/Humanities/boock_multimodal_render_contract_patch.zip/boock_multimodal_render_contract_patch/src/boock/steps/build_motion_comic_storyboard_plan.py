from __future__ import annotations

from typing import Any, Dict

from boock.motion_comic.storyboard_planner import build_motion_comic_storyboard_plan


def run_build_motion_comic_storyboard_plan(input_payload: Dict[str, Any]) -> Dict[str, Any]:
    plan = build_motion_comic_storyboard_plan(
        book_version_id=str(input_payload["book_version_id"]),
        variant_id=str(input_payload["variant_id"]),
        chapter_id=str(input_payload.get("chapter_id", "")),
        scene_department_packet=input_payload["scene_department_packet"],
        ams_or_step_outline=input_payload.get("ams") or input_payload.get("step_outline"),
        camera_script=input_payload.get("camera_script"),
        motion_comic_design_packet=input_payload.get("motion_comic_design_packet"),
        reference_lock_manifest=input_payload.get("reference_lock_manifest"),
        panels_per_beat=int(input_payload.get("panels_per_beat") or 1),
        strict=bool(input_payload.get("strict", True)),
    )
    return {**input_payload, "motion_comic_storyboard_plan": plan}
