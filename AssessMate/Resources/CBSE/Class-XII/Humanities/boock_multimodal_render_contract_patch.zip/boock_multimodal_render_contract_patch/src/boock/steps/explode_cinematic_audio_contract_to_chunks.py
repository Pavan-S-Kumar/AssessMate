from __future__ import annotations

from typing import Any, Dict

from boock.audio.cinematic_contract import explode_cinematic_audio_contract_to_chunks


def run_explode_cinematic_audio_contract_to_chunks(input_payload: Dict[str, Any]) -> Dict[str, Any]:
    manifest = explode_cinematic_audio_contract_to_chunks(
        cinematic_audio_render_contract=input_payload["cinematic_audio_render_contract"],
        max_segments_per_chunk=int(input_payload.get("max_segments_per_chunk") or 12),
    )
    return {**input_payload, "cinematic_audio_chunk_manifest": manifest}
