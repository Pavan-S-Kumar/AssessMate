from __future__ import annotations

from typing import Any, Dict

from boock.image.render_context import build_image_validator_metadata


def run_build_image_validator_metadata(input_payload: Dict[str, Any]) -> Dict[str, Any]:
    meta = build_image_validator_metadata(
        image_render_context_pack=input_payload["image_render_context_pack"],
        generated_asset=input_payload.get("generated_asset") or {},
        detector_output=input_payload.get("detector_output") or {},
    )
    return {**input_payload, "image_validator_metadata": meta}
