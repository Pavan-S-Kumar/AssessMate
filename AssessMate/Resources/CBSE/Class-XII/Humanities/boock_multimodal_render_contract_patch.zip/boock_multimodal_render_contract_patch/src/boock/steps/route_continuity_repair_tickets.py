from __future__ import annotations

from typing import Any, Dict

from boock.production.publish_router import route_continuity_repair_tickets


def run_route_continuity_repair_tickets(input_payload: Dict[str, Any]) -> Dict[str, Any]:
    route_plan = route_continuity_repair_tickets(
        continuity_report=input_payload["continuity_report"],
        repair_ticket_manifest=input_payload.get("repair_ticket_manifest"),
        pipeline_artifacts=input_payload.get("pipeline_artifacts"),
        max_auto_repair_attempts=int(input_payload.get("max_auto_repair_attempts") or 2),
    )
    return {**input_payload, "continuity_repair_route_plan": route_plan}
