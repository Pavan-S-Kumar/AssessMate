from __future__ import annotations

from typing import Any, Dict

from boock.image.render_context import build_image_render_context_pack


def run_build_image_render_context_pack(input_payload: Dict[str, Any]) -> Dict[str, Any]:
    pack = build_image_render_context_pack(
        book_version_id=str(input_payload["book_version_id"]),
        variant_id=str(input_payload["variant_id"]),
        chapter_id=str(input_payload.get("chapter_id", "")),
        scene_department_packet=input_payload["scene_department_packet"],
        reference_lock_manifest=input_payload["reference_lock_manifest"],
        shot=input_payload.get("shot"),
        modality_contract=input_payload.get("modality_contract"),
        canon_contract=input_payload.get("canon_contract"),
        image_task=str(input_payload.get("image_task") or "shot_keyframe"),
        strict=bool(input_payload.get("strict", True)),
    )
    return {**input_payload, "image_render_context_pack": pack}
