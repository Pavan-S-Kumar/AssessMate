"""Shared render-contract utilities for Boock multimodal render enforcement."""
