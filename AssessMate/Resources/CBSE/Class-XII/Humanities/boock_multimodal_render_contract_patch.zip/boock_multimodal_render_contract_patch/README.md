# Boock Multimodal Render Contract Enforcement Patch

This drop-in patch connects the upstream Boock canon/screenwriting/production artifacts to downstream renderers.

It implements the five remaining high-priority enforcement points:

1. **Image pipeline**: `image_render_context_pack`, persistent visual reference locks, and validator metadata.
2. **Video pipeline**: `camera_script + scene_department_packet` are mandatory for cinematic shot timeline and render prompts.
3. **Audio pipeline**: `performance_timeline + stem_plan` are mandatory for cinematic audiobook and video audio.
4. **Motion comic pipeline**: panel/storyboard planning now happens before segmented layer generation.
5. **All pipelines**: continuity validation gates publishing and routes repair tickets to targeted rerender steps.

This patch is intentionally a contract/enforcement layer. It does not replace image/video/audio model providers. It forces those providers to consume the right upstream contracts and to emit validator-friendly metadata.

## New modules

```text
src/boock/image/render_context.py
src/boock/video/contracted_shots.py
src/boock/audio/cinematic_contract.py
src/boock/motion_comic/storyboard_planner.py
src/boock/production/publish_router.py
src/boock/render_contracts/common.py
```

## New runner steps

```text
build_image_reference_locks
build_image_render_context_pack
build_image_validator_metadata
compile_cinematic_shot_timeline_from_contracts
build_video_render_prompt_pack
build_cinematic_audio_render_contract
explode_cinematic_audio_contract_to_chunks
build_motion_comic_storyboard_plan
build_motion_comic_panel_render_manifest
enforce_multimodal_continuity_publish_gate
route_continuity_repair_tickets
```

## Recommended pipeline order

```text
retrieve_canon_context
  -> build_screenwriter_beat_sheet
  -> build_step_outline_from_beat_sheet
  -> generate_adaptation_master_script
  -> validate_ams_against_beat_sheet
  -> lock_ams_revision
  -> build_production_breakdown_manifest
  -> build_department_bibles_from_breakdown
  -> build_scene_department_packet
  -> build_image_reference_locks
  -> generate_scene_blocking_plan
  -> build_camera_script_from_blocking
  -> compile_cinematic_shot_timeline_from_contracts
  -> build_video_render_prompt_pack
  -> build_image_render_context_pack
  -> build_cinematic_audio_render_contract
  -> build_motion_comic_storyboard_plan
  -> build_motion_comic_panel_render_manifest
  -> render image/video/audio/motion-comic assets
  -> build_image_validator_metadata
  -> build_production_continuity_validation_report
  -> enforce_multimodal_continuity_publish_gate
  -> route_continuity_repair_tickets
```

## Contract rule

No downstream production render should start from raw prose alone.

Every render should carry:

```text
book_version_id
variant_id
chapter_id
script_version_id
scene_id
beat_id
shot_id or panel_id when applicable
source_scope_ids
required_canon_fact_ids
required_modality_entry_ids
required_department_entry_ids
location_id
costume_ids
prop_ids
reference_lock_ids
validator metadata
```

## Image pipeline

Build reference locks first:

```python
from boock.image.render_context import build_reference_lock_manifest

reference_locks = build_reference_lock_manifest(
    book_version_id=book_version_id,
    variant_id=variant_id,
    chapter_id=chapter_id,
    scene_department_packet=scene_department_packet,
    department_bibles_bundle=department_bibles_bundle,
    existing_reference_assets=existing_reference_assets,
)
```

Then build the image render context:

```python
from boock.image.render_context import build_image_render_context_pack

context = build_image_render_context_pack(
    book_version_id=book_version_id,
    variant_id=variant_id,
    chapter_id=chapter_id,
    scene_department_packet=scene_department_packet,
    reference_lock_manifest=reference_locks,
    shot=shot,
    image_task="video_keyframe",
)
```

The context includes prompt blocks and a validator metadata template. After render, normalize detector or renderer metadata:

```python
from boock.image.render_context import build_image_validator_metadata

metadata = build_image_validator_metadata(
    image_render_context_pack=context,
    generated_asset=generated_asset,
    detector_output=detector_output,
)
```

## Video pipeline

Video generation must now start from the camera script and scene department packet:

```python
from boock.video.contracted_shots import compile_cinematic_shot_timeline_from_camera_script

timeline = compile_cinematic_shot_timeline_from_camera_script(
    book_version_id=book_version_id,
    variant_id=variant_id,
    chapter_id=chapter_id,
    camera_script=camera_script,
    scene_department_packet=scene_department_packet,
    reference_lock_manifest=reference_locks,
)
```

Then build provider-facing prompt packs:

```python
from boock.video.contracted_shots import build_video_render_prompt_pack

prompt_pack = build_video_render_prompt_pack(
    contracted_shot_timeline=timeline,
    scene_department_packet=scene_department_packet,
    reference_lock_manifest=reference_locks,
)
```

## Audio pipeline

Cinematic audio must use the performance timeline and stem plan:

```python
from boock.audio.cinematic_contract import build_cinematic_audio_render_contract

contract = build_cinematic_audio_render_contract(
    book_version_id=book_version_id,
    variant_id=variant_id,
    chapter_id=chapter_id,
    performance_timeline=performance_timeline,
    stem_plan=stem_plan,
    audio_design_packet=audio_design_packet,
    scene_department_packet=scene_department_packet,
    output_mode="audiobook",
)
```

For video audio:

```python
contract = build_cinematic_audio_render_contract(
    ...,
    output_mode="video",
)
```

Narrator bridges are excluded from the video mix by default unless explicitly marked as video V.O.

## Motion comic pipeline

Plan panels before segmented layer generation:

```python
from boock.motion_comic.storyboard_planner import build_motion_comic_storyboard_plan

storyboard = build_motion_comic_storyboard_plan(
    book_version_id=book_version_id,
    variant_id=variant_id,
    chapter_id=chapter_id,
    scene_department_packet=scene_department_packet,
    ams_or_step_outline=ams_or_step_outline,
    camera_script=camera_script,
    motion_comic_design_packet=motion_comic_design_packet,
    reference_lock_manifest=reference_locks,
)
```

Then create layer render jobs:

```python
from boock.motion_comic.storyboard_planner import build_motion_comic_panel_render_manifest

panel_manifest = build_motion_comic_panel_render_manifest(
    motion_comic_storyboard_plan=storyboard,
    reference_lock_manifest=reference_locks,
)
```

## Publish gate and repair routing

```python
from boock.production.publish_router import (
    enforce_multimodal_continuity_publish_gate,
    route_continuity_repair_tickets,
)

gated_manifest = enforce_multimodal_continuity_publish_gate(
    publish_manifest=publish_manifest,
    continuity_report=production_continuity_validation_report,
)

route_plan = route_continuity_repair_tickets(
    continuity_report=production_continuity_validation_report,
    repair_ticket_manifest=continuity_repair_ticket_manifest,
)
```

Repair routing is targeted. For example:

```text
missing_hero_prop -> generate_prop_layer_or_rerender_shot
missing_costume -> rerender_visual_asset_with_costume_bible
wrong_location -> rerender_scene_with_location_bible
missing_sound_cue -> patch_sound_plan_or_stem_manifest
low_audio_qc -> repair_audio_from_qc
motion_comic_missing_layer -> regenerate_motion_comic_layers
```

## Validation

This bundle includes unit tests for:

```text
image context + reference locks
image validator metadata
mandatory camera_script + scene_department_packet
mandatory performance_timeline + stem_plan
motion-comic storyboard planning
publish gating + repair routing
```

Run:

```bash
PYTHONPATH=src python -m unittest discover -s tests -v
python -m compileall src
```

## Notes

This is a drop-in patch bundle, not an in-place edit to the live Boock repository. Register the runner steps from `runner_snippet.py` and connect the existing model provider steps to the new contracts.
