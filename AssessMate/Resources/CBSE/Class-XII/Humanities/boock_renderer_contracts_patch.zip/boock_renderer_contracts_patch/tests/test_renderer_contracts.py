from boock.render_contracts import (
    build_reference_lock_manifest,
    build_image_render_context_pack,
    compile_image_prompt_from_context_pack,
    build_video_render_contract,
    build_audio_render_contract,
    build_motion_comic_panel_plan,
    normalize_render_asset_metadata,
    compile_renderer_contract_bundle,
)

SCENE_PACKET = {
    "scene_id": "ams.sc023",
    "script_version_id": "ams_locked_v01",
    "canon_fact_ids": ["cf_102"],
    "location_id": "ruined_watchtower",
    "time_of_day": "night",
    "weather": "rain",
    "cast": [{"character_id": "mira"}, {"character_id": "arin"}],
    "wardrobe": [{"costume_id": "mira_travel_cloak_rain"}],
    "props": [{"prop_id": "black_seal", "story_critical": True}],
    "set_dressing": ["broken archways"],
}

DEPT = {
    "department_bibles_bundle_id": "dept_v01",
    "location_bible": {"entries": [{"location_id": "ruined_watchtower", "palette": ["wet slate"]}]},
    "costume_bible": {"entries": [{"costume_id": "mira_travel_cloak_rain", "silhouette": "hooded cloak"}]},
    "prop_bible": {"entries": [{"prop_id": "black_seal", "description": "black wax seal"}]},
}

CAMERA = {
    "camera_script_id": "cam_v01",
    "shots": [
        {"shot_id": "sh1", "scene_id": "ams.sc023", "beat_id": "b01", "line_class": "onscreen_dialogue", "speaker_role": "character", "speaker": "mira", "lipsync_target_id": "mira"},
        {"shot_id": "sh2", "scene_id": "ams.sc023", "beat_id": "b02", "line_class": "narrator_bridge", "speaker_role": "narrator", "render_policy": "voiceover_broll"},
    ],
}

PERF = {
    "performance_timeline_id": "perf_v01",
    "segments": [
        {"segment_id": "s1", "line_class": "onscreen_dialogue", "speaker_id": "mira", "text": "You lied.", "emotion": "controlled anger"},
        {"segment_id": "s2", "line_class": "narrator_bridge", "speaker_id": "narrator", "text": "Rain struck the stones."},
    ],
}


def test_reference_locks_include_costume_prop_location():
    locks = build_reference_lock_manifest(department_bibles_bundle=DEPT)
    types = {x["lock_type"] for x in locks["locks"]}
    assert "costume" in types
    assert "prop" in types
    assert "location" in types


def test_image_context_and_prompt_include_required_details():
    refs = build_reference_lock_manifest(department_bibles_bundle=DEPT)
    ctx = build_image_render_context_pack(scene_department_packet=SCENE_PACKET, department_bibles_bundle=DEPT, reference_lock_manifest=refs)
    prompt = compile_image_prompt_from_context_pack(ctx)
    assert ctx["visual_requirements"]["location_id"] == "ruined_watchtower"
    assert "black_seal" in ctx["visual_requirements"]["prop_ids"]
    assert "ruined_watchtower" in prompt["prompt"]
    assert "Do not omit hero props" in prompt["negative_prompt"]


def test_video_contract_locks_narration_away_from_lipsync():
    contract = build_video_render_contract(camera_script=CAMERA, scene_department_packets=[SCENE_PACKET], department_bibles_bundle=DEPT)
    by_id = {s["shot_id"]: s for s in contract["shot_contracts"]}
    assert by_id["sh1"]["audio_sync_policy"] == "drive_lipsync_from_dialogue_stem"
    assert by_id["sh1"]["lipsync_target_id"] == "mira"
    assert by_id["sh2"]["audio_sync_policy"] == "do_not_drive_lipsync_use_broll_or_reaction"
    assert by_id["sh2"]["editorial_lock"] is True


def test_audio_contract_routes_line_classes_to_buses():
    contract = build_audio_render_contract(performance_timeline=PERF, audio_design_packet={"scene_id": "ams.sc023", "required_foley": ["rain"]})
    buses = [s["bus"] for s in contract["render_segments"]]
    assert "DX_ONSCREEN" in buses
    assert "NARRATOR" in buses
    assert "FOLEY" in contract["stem_buses"]


def test_motion_comic_panel_plan_uses_ams_beats():
    plan = build_motion_comic_panel_plan(
        motion_comic_design_packet={"scene_id": "ams.sc023", "character_layers": ["mira_full_body"], "prop_layers": ["black_seal_layer"]},
        adaptation_master_script={"scenes": [{"scene_id": "ams.sc023", "beats": [{"beat_id": "b01", "line_class": "onscreen_dialogue"}]}]},
    )
    assert plan["panels"][0]["beat_id"] == "b01"
    assert plan["panels"][0]["required_layers"]["prop_layers"] == ["black_seal_layer"]


def test_normalized_metadata_merges_detector_and_contract():
    refs = build_reference_lock_manifest(department_bibles_bundle=DEPT)
    ctx = build_image_render_context_pack(scene_department_packet=SCENE_PACKET, department_bibles_bundle=DEPT, reference_lock_manifest=refs)
    asset = normalize_render_asset_metadata(
        render_asset={"uri": "s3://bucket/frame.png"},
        contract=ctx,
        detector_output={"detected_character_ids": ["mira"], "detected_location_id": "ruined_watchtower", "continuity_score": 0.91},
    )
    assert asset["metadata"]["scene_id"] == "ams.sc023"
    assert asset["metadata"]["detected_character_ids"] == ["mira"]
    assert asset["metadata"]["continuity_score"] == 0.91


def test_bundle_compiles_and_validates():
    bundle = compile_renderer_contract_bundle(
        scene_department_packet=SCENE_PACKET,
        department_bibles_bundle=DEPT,
        camera_script=CAMERA,
        performance_timeline=PERF,
        audio_design_packet={"scene_id": "ams.sc023"},
        motion_comic_design_packet={"scene_id": "ams.sc023"},
    )
    assert bundle["validation_report"]["status"] == "passed"
    assert bundle["video_render_contract"]["summary"]["shot_count"] == 2
