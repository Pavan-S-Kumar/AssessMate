# Patch Notes: Renderer Contract Consumers

## Added

- `reference_lock_manifest` builder for character/costume/prop/location/hair-makeup locks.
- `image_render_context_pack` builder for production-safe image/keyframe generation.
- `image_prompt_contract` compiler with prompt, negative prompt, reference locks, and validator metadata requirements.
- `video_render_contract` compiler from camera script and department packets.
- `audio_render_contract` compiler from performance timeline and audio design packet.
- `motion_comic_panel_plan` builder for panel/layer/micro-motion planning.
- `normalize_render_asset_metadata` helper so produced media can be checked by production continuity validation.
- `compile_renderer_contract_bundle` one-shot integration helper.
- Runner registration snippet.

## Behavioral changes

### Image

Before:

```text
chapter text / loose scene prompt -> image renderer
```

After:

```text
scene_department_packet + department_bibles + modality/canon rules + reference locks -> image_render_context_pack -> image_prompt_contract
```

### Video

Before:

```text
chapter text / narration / dialogue timeline -> shot prompts
```

After:

```text
camera_script + scene_department_packet + reference locks -> shot-level render contracts
```

Narrator/offscreen material is automatically locked away from lipsync policy.

### Audio

Before:

```text
chapter prose -> audio_script -> TTS
```

After:

```text
performance_timeline + audio_design_packet + stem plan -> bus-aware audio_render_contract
```

### Motion comic

Before:

```text
flat panel image or generic rail overlay
```

After:

```text
AMS/step-outline beats + motion_comic_design_packet -> panel plan -> segmented layer renderer
```

## Integration dependency

This patch expects the previous artifacts to exist, but tolerates partial inputs:

- `scene_department_packet`
- `department_bibles_bundle`
- `camera_script`
- `adaptation_performance_timeline`
- `audio_design_packet`
- `motion_comic_design_packet`
- `modality_contract`
- `canon_contract`

## Recommended next follow-up

Patch the actual live image/video/audio renderer functions so they reject raw-prose-only inputs in production mode unless a debug flag is set.
