from __future__ import annotations
from typing import Any, Dict
from boock.render_contracts import validate_render_contract_bundle


def run_validate_render_contract_bundle(input_payload: Dict[str, Any]) -> Dict[str, Any]:
    report = validate_render_contract_bundle(input_payload.get("renderer_contract_bundle") or input_payload)
    return {**input_payload, "render_contract_validation_report": report}
