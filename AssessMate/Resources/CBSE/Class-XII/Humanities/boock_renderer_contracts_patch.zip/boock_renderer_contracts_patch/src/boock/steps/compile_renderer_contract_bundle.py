from __future__ import annotations
from typing import Any, Dict
from boock.render_contracts import compile_renderer_contract_bundle


def run_compile_renderer_contract_bundle(input_payload: Dict[str, Any]) -> Dict[str, Any]:
    bundle = compile_renderer_contract_bundle(
        scene_department_packet=input_payload["scene_department_packet"],
        department_bibles_bundle=input_payload.get("department_bibles_bundle"),
        production_breakdown_manifest=input_payload.get("production_breakdown_manifest"),
        modality_contract=input_payload.get("modality_contract"),
        canon_contract=input_payload.get("canon_contract"),
        camera_script=input_payload.get("camera_script"),
        performance_timeline=input_payload.get("performance_timeline"),
        audio_design_packet=input_payload.get("audio_design_packet"),
        adaptation_stem_plan=input_payload.get("adaptation_stem_plan"),
        motion_comic_design_packet=input_payload.get("motion_comic_design_packet"),
        scene_blocking_plan=input_payload.get("scene_blocking_plan"),
        adaptation_master_script=input_payload.get("adaptation_master_script"),
        step_outline=input_payload.get("step_outline"),
        existing_reference_assets=input_payload.get("existing_reference_assets"),
    )
    return {**input_payload, "renderer_contract_bundle": bundle}
