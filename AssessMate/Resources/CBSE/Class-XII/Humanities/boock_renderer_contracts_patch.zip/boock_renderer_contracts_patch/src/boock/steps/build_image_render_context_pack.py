from __future__ import annotations
from typing import Any, Dict
from boock.render_contracts import build_image_render_context_pack


def run_build_image_render_context_pack(input_payload: Dict[str, Any]) -> Dict[str, Any]:
    context = build_image_render_context_pack(
        scene_department_packet=input_payload["scene_department_packet"],
        department_bibles_bundle=input_payload.get("department_bibles_bundle"),
        modality_contract=input_payload.get("modality_contract"),
        canon_contract=input_payload.get("canon_contract"),
        shot=input_payload.get("shot"),
        beat=input_payload.get("beat"),
        reference_lock_manifest=input_payload.get("reference_lock_manifest"),
        render_mode=str(input_payload.get("render_mode") or "image"),
    )
    return {**input_payload, "image_render_context_pack": context}
