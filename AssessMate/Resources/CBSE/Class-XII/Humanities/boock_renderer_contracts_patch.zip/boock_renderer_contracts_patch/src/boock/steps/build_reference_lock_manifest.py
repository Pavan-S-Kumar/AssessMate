from __future__ import annotations
from typing import Any, Dict
from boock.render_contracts import build_reference_lock_manifest


def run_build_reference_lock_manifest(input_payload: Dict[str, Any]) -> Dict[str, Any]:
    manifest = build_reference_lock_manifest(
        department_bibles_bundle=input_payload.get("department_bibles_bundle"),
        production_breakdown_manifest=input_payload.get("production_breakdown_manifest"),
        modality_bible=input_payload.get("modality_bible"),
        existing_reference_assets=input_payload.get("existing_reference_assets"),
    )
    return {**input_payload, "reference_lock_manifest": manifest}
