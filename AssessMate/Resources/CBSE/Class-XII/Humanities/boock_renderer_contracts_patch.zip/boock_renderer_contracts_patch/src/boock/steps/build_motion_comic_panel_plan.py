from __future__ import annotations
from typing import Any, Dict
from boock.render_contracts import build_motion_comic_panel_plan


def run_build_motion_comic_panel_plan(input_payload: Dict[str, Any]) -> Dict[str, Any]:
    plan = build_motion_comic_panel_plan(
        motion_comic_design_packet=input_payload["motion_comic_design_packet"],
        scene_blocking_plan=input_payload.get("scene_blocking_plan"),
        adaptation_master_script=input_payload.get("adaptation_master_script"),
        step_outline=input_payload.get("step_outline"),
        panel_density=str(input_payload.get("panel_density") or "balanced"),
    )
    return {**input_payload, "motion_comic_panel_plan": plan}
