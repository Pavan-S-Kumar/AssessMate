from __future__ import annotations
from typing import Any, Dict
from boock.render_contracts import build_audio_render_contract


def run_build_audio_render_contract_from_performance_timeline(input_payload: Dict[str, Any]) -> Dict[str, Any]:
    contract = build_audio_render_contract(
        performance_timeline=input_payload["performance_timeline"],
        audio_design_packet=input_payload.get("audio_design_packet"),
        adaptation_stem_plan=input_payload.get("adaptation_stem_plan"),
        modality_contract=input_payload.get("modality_contract"),
        product_mode=str(input_payload.get("product_mode") or "cinematic_audiobook"),
    )
    return {**input_payload, "audio_render_contract": contract}
