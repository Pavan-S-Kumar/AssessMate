from __future__ import annotations

import hashlib
import json
import re
from copy import deepcopy
from typing import Any, Dict, Iterable, List, Mapping, Optional, Sequence, Tuple

Json = Dict[str, Any]


# ---------------------------------------------------------------------------
# Small helpers
# ---------------------------------------------------------------------------

def _as_list(value: Any) -> List[Any]:
    if value is None:
        return []
    if isinstance(value, list):
        return value
    if isinstance(value, tuple):
        return list(value)
    return [value]


def _as_dict(value: Any) -> Json:
    return value if isinstance(value, dict) else {}


def _first_nonempty(*values: Any, default: Any = "") -> Any:
    for v in values:
        if v not in (None, "", [], {}):
            return v
    return default


def _stable_id(prefix: str, *parts: Any) -> str:
    raw = json.dumps(parts, sort_keys=True, ensure_ascii=False, default=str)
    digest = hashlib.sha1(raw.encode("utf-8")).hexdigest()[:12]
    normalized = re.sub(r"[^a-zA-Z0-9_]+", "_", prefix.strip().lower()).strip("_") or "id"
    return f"{normalized}_{digest}"


def _dedupe_keep_order(items: Iterable[Any]) -> List[Any]:
    out: List[Any] = []
    seen: set[str] = set()
    for item in items:
        key = json.dumps(item, sort_keys=True, ensure_ascii=False, default=str) if isinstance(item, (dict, list)) else str(item)
        if key not in seen and item not in (None, "", [], {}):
            seen.add(key)
            out.append(item)
    return out


def _stringify_list(items: Iterable[Any]) -> List[str]:
    out = []
    for item in _as_list(items):
        if isinstance(item, dict):
            candidate = _first_nonempty(
                item.get("id"), item.get("character_id"), item.get("costume_id"), item.get("prop_id"),
                item.get("location_id"), item.get("name"), item.get("label"), default="",
            )
            if candidate:
                out.append(str(candidate))
        elif item not in (None, ""):
            out.append(str(item))
    return _dedupe_keep_order(out)


def _lookup_by_any_id(items: Sequence[Any], *keys: str) -> Dict[str, Json]:
    out: Dict[str, Json] = {}
    for item in items:
        if not isinstance(item, dict):
            continue
        for k in keys:
            v = item.get(k)
            if v not in (None, ""):
                out[str(v)] = item
    return out


def _scene_id(scene_or_packet: Mapping[str, Any]) -> str:
    return str(_first_nonempty(
        scene_or_packet.get("scene_id"),
        scene_or_packet.get("ams_scene_id"),
        scene_or_packet.get("source_scene_id"),
        default="scene_unknown",
    ))


def _script_version_id(*sources: Mapping[str, Any]) -> str:
    for src in sources:
        v = _first_nonempty(src.get("script_version_id"), src.get("ams_version_id"), src.get("locked_ams_revision_id"), default="")
        if v:
            return str(v)
    return "script_unversioned"


def _canon_ids(*sources: Mapping[str, Any]) -> List[str]:
    ids: List[str] = []
    for src in sources:
        ids += _stringify_list(src.get("required_canon_fact_ids"))
        ids += _stringify_list(src.get("canon_fact_ids"))
        if isinstance(src.get("canon_contract"), dict):
            ids += _stringify_list(src["canon_contract"].get("required_fact_ids"))
    return _dedupe_keep_order(ids)


def _modality_entry_ids(*sources: Mapping[str, Any]) -> List[str]:
    ids: List[str] = []
    for src in sources:
        ids += _stringify_list(src.get("required_modality_entry_ids"))
        if isinstance(src.get("modality_contract"), dict):
            ids += _stringify_list(src["modality_contract"].get("required_entry_ids"))
        if isinstance(src.get("multimodal_generation_contract"), dict):
            ids += _stringify_list(src["multimodal_generation_contract"].get("required_modality_entry_ids"))
    return _dedupe_keep_order(ids)


def _department_entry_ids(*sources: Mapping[str, Any]) -> List[str]:
    ids: List[str] = []
    for src in sources:
        ids += _stringify_list(src.get("required_department_entry_ids"))
        ids += _stringify_list(src.get("department_entry_ids"))
    return _dedupe_keep_order(ids)


def _extract_scene_packets(production_breakdown_manifest: Optional[Json], scene_department_packets: Optional[Any]) -> List[Json]:
    packets: List[Json] = []
    for p in _as_list(scene_department_packets):
        if isinstance(p, dict):
            packets.append(p)
    pb = _as_dict(production_breakdown_manifest)
    for key in ("scene_breakdowns", "scenes", "breakdowns", "production_breakdowns"):
        for p in _as_list(pb.get(key)):
            if isinstance(p, dict):
                packets.append(p)
    return packets


def _find_scene_packet(scene_id: str, packets: Sequence[Json]) -> Json:
    for p in packets:
        if _scene_id(p) == scene_id:
            return p
    return {}


def _extract_department_bible_items(bundle: Optional[Json], key: str) -> List[Json]:
    bundle = _as_dict(bundle)
    value = bundle.get(key)
    if isinstance(value, list):
        return [x for x in value if isinstance(x, dict)]
    if isinstance(value, dict):
        # tolerate both {entries:[...]} and {id:{...}}
        entries = value.get("entries") or value.get("items") or value.get("records")
        if isinstance(entries, list):
            return [x for x in entries if isinstance(x, dict)]
        return [x for x in value.values() if isinstance(x, dict)]
    return []


def _extract_modality_rules(contract: Optional[Json], family: str = "visual") -> List[str]:
    c = _as_dict(contract)
    rules: List[str] = []
    for key in (
        "hard_modality_constraints",
        "soft_modality_guidance",
        "interpretive_modality_guidance",
        "negative_modality_constraints",
        "all_entries",
    ):
        for item in _as_list(c.get(key)):
            if isinstance(item, dict):
                text = _first_nonempty(item.get("rule"), item.get("constraint"), item.get("text"), item.get("rationale"), default="")
                if text:
                    rules.append(str(text))
            elif item not in (None, ""):
                rules.append(str(item))
    family_key = {
        "visual": "visual_comic_bible",
        "video": "cinematic_video_bible",
        "audio": "audio_bible",
    }.get(family, family)
    for item in _as_list(c.get(family_key)):
        if isinstance(item, dict):
            text = _first_nonempty(item.get("rule"), item.get("text"), item.get("rationale"), default="")
            if text:
                rules.append(str(text))
        elif item not in (None, ""):
            rules.append(str(item))
    return _dedupe_keep_order(rules)


def _negative_constraints(*sources: Mapping[str, Any]) -> List[str]:
    neg: List[str] = []
    for src in sources:
        neg += _stringify_list(src.get("negative_constraints"))
        neg += _stringify_list(src.get("must_not_do"))
        neg += _stringify_list(src.get("forbidden"))
        if isinstance(src.get("canon_contract"), dict):
            for item in _as_list(src["canon_contract"].get("negative_canon")):
                if isinstance(item, dict):
                    neg.append(str(_first_nonempty(item.get("assertion"), item.get("rule"), default="")))
                elif item:
                    neg.append(str(item))
    return _dedupe_keep_order([x for x in neg if x])


# ---------------------------------------------------------------------------
# Reference locks
# ---------------------------------------------------------------------------

def build_reference_lock_manifest(
    *,
    department_bibles_bundle: Optional[Json] = None,
    production_breakdown_manifest: Optional[Json] = None,
    modality_bible: Optional[Json] = None,
    existing_reference_assets: Optional[Sequence[Json]] = None,
) -> Json:
    """Create stable reusable visual/sonic reference locks.

    This is intentionally renderer-agnostic: the manifest can later be resolved to
    real image references, LoRAs, style refs, voice refs, or asset-library IDs.
    """
    dept = _as_dict(department_bibles_bundle)
    pb = _as_dict(production_breakdown_manifest)
    modality = _as_dict(modality_bible)

    locks: List[Json] = []

    def add_lock(lock_type: str, subject_id: str, payload: Json, source: str) -> None:
        if not subject_id:
            return
        lock = {
            "reference_lock_id": _stable_id(f"ref_{lock_type}", subject_id, payload),
            "lock_type": lock_type,
            "subject_id": str(subject_id),
            "source": source,
            "status": "needs_reference_asset",
            "description": str(_first_nonempty(
                payload.get("description"), payload.get("rule"), payload.get("silhouette"), payload.get("architecture"), payload.get("name"), default="",
            )),
            "attributes": deepcopy(payload),
            "asset_refs": [],
            "continuity_rules": _as_list(payload.get("continuity_rules")),
            "canon_fact_ids": _stringify_list(payload.get("canon_fact_ids")),
        }
        locks.append(lock)

    # Department bibles
    for item in _extract_department_bible_items(dept, "costume_bible"):
        add_lock("costume", str(_first_nonempty(item.get("costume_id"), item.get("id"), item.get("name"), default="")), item, "costume_bible")
    for item in _extract_department_bible_items(dept, "prop_bible"):
        add_lock("prop", str(_first_nonempty(item.get("prop_id"), item.get("id"), item.get("name"), default="")), item, "prop_bible")
    for item in _extract_department_bible_items(dept, "location_bible"):
        add_lock("location", str(_first_nonempty(item.get("location_id"), item.get("id"), item.get("name"), default="")), item, "location_bible")
    for item in _extract_department_bible_items(dept, "hair_makeup_bible"):
        add_lock("hair_makeup", str(_first_nonempty(item.get("hair_makeup_id"), item.get("id"), item.get("character_id"), default="")), item, "hair_makeup_bible")

    # Production breakdown can introduce subjects before full bibles exist.
    for scene in _extract_scene_packets(pb, None):
        sid = _scene_id(scene)
        for cast in _as_list(scene.get("cast")):
            if isinstance(cast, dict):
                cid = str(_first_nonempty(cast.get("character_id"), cast.get("id"), cast.get("name"), default=""))
                add_lock("character", cid, {**cast, "scene_id": sid}, "production_breakdown_manifest")
        for wardrobe in _as_list(scene.get("wardrobe") or scene.get("costumes")):
            if isinstance(wardrobe, dict):
                costume_id = str(_first_nonempty(wardrobe.get("costume_id"), wardrobe.get("id"), default=""))
                add_lock("costume", costume_id, {**wardrobe, "scene_id": sid}, "production_breakdown_manifest")
        for prop in _as_list(scene.get("props") or scene.get("hero_props")):
            if isinstance(prop, dict):
                prop_id = str(_first_nonempty(prop.get("prop_id"), prop.get("id"), prop.get("name"), default=""))
                add_lock("prop", prop_id, {**prop, "scene_id": sid}, "production_breakdown_manifest")

    # Modality bible entries may include appearance/location constraints.
    for entry in _as_list(modality.get("entries") or modality.get("modality_bible_entries")):
        if not isinstance(entry, dict):
            continue
        etype = str(entry.get("entry_type") or "").lower()
        if etype in {"character_appearance", "costume_prop", "location_design", "color_lighting"}:
            subject = str(_first_nonempty(entry.get("entities"), entry.get("entry_id"), default=""))
            if isinstance(entry.get("entities"), list) and entry["entities"]:
                subject = str(entry["entities"][0])
            add_lock(etype, subject, entry, "modality_bible")

    # Existing references attach to locks when possible.
    existing_refs = [x for x in _as_list(existing_reference_assets) if isinstance(x, dict)]
    refs_by_subject = _lookup_by_any_id(existing_refs, "subject_id", "character_id", "costume_id", "prop_id", "location_id")
    for lock in locks:
        ref = refs_by_subject.get(str(lock["subject_id"]))
        if ref:
            lock["status"] = "locked"
            lock["asset_refs"].append(ref)

    unique_locks_by_id: Dict[str, Json] = {}
    for lock in locks:
        unique_locks_by_id[lock["reference_lock_id"]] = lock

    return {
        "artifact_type": "reference_lock_manifest",
        "reference_lock_manifest_id": _stable_id("reference_locks", dept.get("department_bibles_bundle_id"), pb.get("production_breakdown_manifest_id"), modality.get("modality_bible_id")),
        "version": "1.0",
        "locks": list(unique_locks_by_id.values()),
        "summary": {
            "total_locks": len(unique_locks_by_id),
            "locked_count": sum(1 for x in unique_locks_by_id.values() if x["status"] == "locked"),
            "needs_reference_asset_count": sum(1 for x in unique_locks_by_id.values() if x["status"] != "locked"),
        },
    }


# ---------------------------------------------------------------------------
# Image render context + prompt compiler
# ---------------------------------------------------------------------------

def _visual_requirements_from_scene(scene: Json, department_bibles_bundle: Optional[Json] = None) -> Json:
    dept = _as_dict(department_bibles_bundle)
    location_id = str(_first_nonempty(scene.get("location_id"), _as_dict(scene.get("location")).get("location_id"), default=""))
    cast = _as_list(scene.get("cast") or scene.get("characters") or scene.get("required_characters"))
    wardrobe = _as_list(scene.get("wardrobe") or scene.get("costumes") or scene.get("required_costumes"))
    props = _as_list(scene.get("props") or scene.get("required_props"))
    hero_props = _as_list(scene.get("hero_props") or [p for p in props if isinstance(p, dict) and p.get("story_critical")])
    set_dressing = _as_list(scene.get("set_dressing") or scene.get("background_identity_markers"))

    location_items = _extract_department_bible_items(dept, "location_bible")
    location_by_id = _lookup_by_any_id(location_items, "location_id", "id", "name")
    location_design = location_by_id.get(location_id, {}) if location_id else {}

    return {
        "location_id": location_id,
        "location_design": location_design,
        "time_of_day": str(_first_nonempty(scene.get("time_of_day"), scene.get("daypart"), default="")),
        "weather": str(_first_nonempty(scene.get("weather"), scene.get("atmosphere"), default="")),
        "characters": cast,
        "character_ids": _stringify_list(cast),
        "wardrobe": wardrobe,
        "costume_ids": _stringify_list(wardrobe),
        "props": props,
        "prop_ids": _stringify_list(props),
        "hero_props": hero_props,
        "hero_prop_ids": _stringify_list(hero_props),
        "set_dressing": set_dressing,
        "vfx": _as_list(scene.get("vfx") or scene.get("effects")),
        "color_palette": _as_list(scene.get("color_palette") or scene.get("palette") or location_design.get("palette")),
        "lighting": _as_dict(scene.get("lighting") or scene.get("color_lighting")),
    }


def build_image_render_context_pack(
    *,
    scene_department_packet: Json,
    department_bibles_bundle: Optional[Json] = None,
    modality_contract: Optional[Json] = None,
    canon_contract: Optional[Json] = None,
    shot: Optional[Json] = None,
    beat: Optional[Json] = None,
    reference_lock_manifest: Optional[Json] = None,
    render_mode: str = "image",
) -> Json:
    scene = _as_dict(scene_department_packet)
    shot = _as_dict(shot)
    beat = _as_dict(beat)
    ref_manifest = _as_dict(reference_lock_manifest)

    sid = _scene_id(scene)
    bid = str(_first_nonempty(shot.get("beat_id"), beat.get("beat_id"), scene.get("beat_id"), default=""))
    shot_id = str(_first_nonempty(shot.get("shot_id"), default=""))
    visual = _visual_requirements_from_scene(scene, department_bibles_bundle)

    # Filter reference locks to things this image needs.
    needed_subjects = set(visual["character_ids"] + visual["costume_ids"] + visual["prop_ids"] + visual["hero_prop_ids"] + ([visual["location_id"]] if visual["location_id"] else []))
    reference_locks = [
        lock for lock in _as_list(ref_manifest.get("locks"))
        if isinstance(lock, dict) and str(lock.get("subject_id")) in needed_subjects
    ]

    modality_rules = _extract_modality_rules(modality_contract, family="visual")
    negative = _negative_constraints(scene, beat, shot, _as_dict(canon_contract), _as_dict(modality_contract))
    negative += ["Do not change required costume identities.", "Do not omit hero props.", "Do not reveal negative canon visually before its reveal beat."]

    context = {
        "artifact_type": "image_render_context_pack",
        "image_render_context_pack_id": _stable_id("image_context", sid, bid, shot_id, render_mode),
        "version": "1.0",
        "render_mode": render_mode,
        "script_version_id": _script_version_id(scene, shot, beat),
        "scene_id": sid,
        "beat_id": bid,
        "shot_id": shot_id,
        "source_scope_ids": _stringify_list(scene.get("source_scope_ids") or beat.get("source_scope_ids") or shot.get("source_scope_ids")),
        "required_canon_fact_ids": _canon_ids(scene, shot, beat, _as_dict(canon_contract)),
        "required_modality_entry_ids": _modality_entry_ids(scene, shot, beat, _as_dict(modality_contract)),
        "required_department_entry_ids": _department_entry_ids(scene, shot, beat),
        "visual_requirements": visual,
        "camera_requirements": {
            "shot_type": str(_first_nonempty(shot.get("shot_type"), shot.get("camera_type"), beat.get("shot_hint"), default="")),
            "subject": str(_first_nonempty(shot.get("subject"), shot.get("visible_speaker_id"), beat.get("speaker"), default="")),
            "composition": str(_first_nonempty(shot.get("composition"), shot.get("composition_note"), default="")),
            "movement": str(_first_nonempty(shot.get("movement"), shot.get("camera_movement"), default="")),
            "lens_intent": str(_first_nonempty(shot.get("lens_intent"), shot.get("lens"), default="")),
        },
        "story_intent": {
            "dramatic_function": str(_first_nonempty(scene.get("dramatic_function"), beat.get("story_function"), beat.get("plot_function"), default="")),
            "emotional_turn": _first_nonempty(scene.get("emotional_turn"), beat.get("emotional_turn"), default=""),
            "dialogue_intent": str(_first_nonempty(beat.get("dialogue_intent"), scene.get("dialogue_strategy"), default="")),
            "visual_intent": str(_first_nonempty(beat.get("visual_intent"), scene.get("visual_strategy"), default="")),
        },
        "reference_locks": reference_locks,
        "style_constraints": modality_rules,
        "negative_constraints": _dedupe_keep_order(negative),
        "required_detector_metadata": [
            "detected_character_ids",
            "detected_costume_ids",
            "detected_prop_ids",
            "detected_location_id",
            "detected_weather",
            "detected_time_of_day",
            "continuity_score",
            "style_score",
        ],
    }
    return context


def compile_image_prompt_from_context_pack(context_pack: Json, *, include_json_attachment: bool = True) -> Json:
    ctx = _as_dict(context_pack)
    visual = _as_dict(ctx.get("visual_requirements"))
    camera = _as_dict(ctx.get("camera_requirements"))
    story = _as_dict(ctx.get("story_intent"))

    char_desc = ", ".join(visual.get("character_ids") or []) or "no visible character required"
    costume_desc = ", ".join(visual.get("costume_ids") or []) or "costume continuity from reference locks"
    prop_desc = ", ".join(visual.get("hero_prop_ids") or visual.get("prop_ids") or []) or "no hero prop required"
    set_desc = ", ".join(_stringify_list(visual.get("set_dressing")))
    palette = ", ".join(_stringify_list(visual.get("color_palette")))
    rules = "; ".join(_stringify_list(ctx.get("style_constraints"))[:8])

    prompt_lines = [
        f"Create a production-consistent cinematic frame for scene {ctx.get('scene_id')} beat {ctx.get('beat_id')}.",
        f"Dramatic function: {story.get('dramatic_function')}",
        f"Emotional turn: {story.get('emotional_turn')}",
        f"Location: {visual.get('location_id')} / {visual.get('time_of_day')} / {visual.get('weather')}",
        f"Characters: {char_desc}",
        f"Costumes: {costume_desc}",
        f"Hero props: {prop_desc}",
        f"Set dressing and background identity markers: {set_desc}",
        f"Color / lighting palette: {palette}",
        f"Camera: {camera.get('shot_type')} subject={camera.get('subject')} composition={camera.get('composition')} lens_intent={camera.get('lens_intent')} movement={camera.get('movement')}",
        f"Modality/style rules: {rules}",
        "Preserve all required character, costume, prop, location, and canon constraints exactly.",
    ]
    prompt = "\n".join([line for line in prompt_lines if line and not line.endswith(": ")])
    negative_prompt = "; ".join(_stringify_list(ctx.get("negative_constraints")))
    out = {
        "artifact_type": "image_prompt_contract",
        "image_prompt_contract_id": _stable_id("image_prompt", ctx.get("image_render_context_pack_id"), prompt, negative_prompt),
        "scene_id": ctx.get("scene_id"),
        "beat_id": ctx.get("beat_id"),
        "shot_id": ctx.get("shot_id"),
        "prompt": prompt,
        "negative_prompt": negative_prompt,
        "reference_locks": ctx.get("reference_locks") or [],
        "required_detector_metadata": ctx.get("required_detector_metadata") or [],
    }
    if include_json_attachment:
        out["context_pack"] = ctx
    return out


# ---------------------------------------------------------------------------
# Video render contracts
# ---------------------------------------------------------------------------

def _shots_from_camera_script(camera_script: Optional[Json]) -> List[Json]:
    cs = _as_dict(camera_script)
    for key in ("shots", "camera_shots", "shot_list", "cinematic_shots"):
        if isinstance(cs.get(key), list):
            return [x for x in cs[key] if isinstance(x, dict)]
    scenes = []
    for sc in _as_list(cs.get("scenes")):
        if isinstance(sc, dict):
            scenes += [x for x in _as_list(sc.get("shots")) if isinstance(x, dict)]
    return scenes


def build_video_render_contract(
    *,
    camera_script: Json,
    scene_department_packets: Optional[Sequence[Json]] = None,
    production_breakdown_manifest: Optional[Json] = None,
    department_bibles_bundle: Optional[Json] = None,
    modality_contract: Optional[Json] = None,
    reference_lock_manifest: Optional[Json] = None,
) -> Json:
    shots = _shots_from_camera_script(camera_script)
    packets = _extract_scene_packets(production_breakdown_manifest, scene_department_packets)
    shot_contracts: List[Json] = []

    for sh in shots:
        sid = str(_first_nonempty(sh.get("scene_id"), sh.get("ams_scene_id"), default="scene_unknown"))
        scene_packet = _find_scene_packet(sid, packets)
        ctx = build_image_render_context_pack(
            scene_department_packet=scene_packet or {"scene_id": sid},
            department_bibles_bundle=department_bibles_bundle,
            modality_contract=modality_contract,
            shot=sh,
            reference_lock_manifest=reference_lock_manifest,
            render_mode="video_shot",
        )
        prompt_contract = compile_image_prompt_from_context_pack(ctx, include_json_attachment=False)
        speaker_role = str(_first_nonempty(sh.get("speaker_role"), _as_dict(sh.get("meta")).get("speaker_role"), default="")).lower()
        line_class = str(_first_nonempty(sh.get("line_class"), _as_dict(sh.get("meta")).get("segment_type"), default="")).lower()
        render_policy = str(_first_nonempty(sh.get("render_policy"), _as_dict(sh.get("meta")).get("preferred_render_policy"), default="")).lower()
        lipsync_target = str(_first_nonempty(sh.get("lipsync_target_id"), _as_dict(sh.get("meta")).get("lipsync_target_id"), default=""))

        is_onscreen_dialogue = line_class in {"onscreen_dialogue", "dialogue"} and (speaker_role in {"character", ""}) and bool(lipsync_target or sh.get("speaker"))
        if is_onscreen_dialogue:
            audio_sync_policy = "drive_lipsync_from_dialogue_stem"
        elif line_class in {"offscreen_dialogue", "voice_over", "narrator_bridge"} or speaker_role in {"narrator", "offscreen"}:
            audio_sync_policy = "do_not_drive_lipsync_use_broll_or_reaction"
        else:
            audio_sync_policy = "no_lipsync_visual_action_or_ambience"

        shot_contracts.append({
            "shot_contract_id": _stable_id("video_shot_contract", sh.get("shot_id"), sid, sh.get("beat_id")),
            "shot_id": str(_first_nonempty(sh.get("shot_id"), default=_stable_id("shot", sid, sh.get("beat_id"), len(shot_contracts)))),
            "scene_id": sid,
            "beat_id": str(_first_nonempty(sh.get("beat_id"), default="")),
            "script_version_id": _script_version_id(sh, scene_packet),
            "camera_script_ref": deepcopy(sh),
            "image_render_context_pack": ctx,
            "prompt_contract": prompt_contract,
            "audio_sync_policy": audio_sync_policy,
            "lipsync_target_id": lipsync_target if is_onscreen_dialogue else "",
            "editorial_lock": bool(_first_nonempty(sh.get("editorial_lock"), _as_dict(sh.get("meta")).get("editorial_lock"), default=False)) or audio_sync_policy != "drive_lipsync_from_dialogue_stem",
            "preferred_render_policy": render_policy or ("talking_head" if is_onscreen_dialogue else "cutaway_or_reaction"),
            "required_output_metadata": ctx.get("required_detector_metadata") + ["shot_id", "scene_id", "beat_id", "lipsync_target_id", "audio_source"],
        })

    return {
        "artifact_type": "video_render_contract",
        "video_render_contract_id": _stable_id("video_render_contract", _as_dict(camera_script).get("camera_script_id"), len(shot_contracts)),
        "version": "1.0",
        "camera_script_id": _as_dict(camera_script).get("camera_script_id"),
        "shot_contracts": shot_contracts,
        "summary": {
            "shot_count": len(shot_contracts),
            "lipsync_shot_count": sum(1 for s in shot_contracts if s["audio_sync_policy"] == "drive_lipsync_from_dialogue_stem"),
            "locked_non_lipsync_count": sum(1 for s in shot_contracts if s["editorial_lock"] and s["audio_sync_policy"] != "drive_lipsync_from_dialogue_stem"),
        },
    }


# ---------------------------------------------------------------------------
# Audio render contract
# ---------------------------------------------------------------------------

_BUS_BY_LINE_CLASS = {
    "onscreen_dialogue": "DX_ONSCREEN",
    "dialogue": "DX_ONSCREEN",
    "offscreen_dialogue": "DX_OFFSCREEN",
    "voice_over": "VO",
    "narrator_bridge": "NARRATOR",
    "internal_voice_over": "VO_INTERNAL",
    "group_walla": "WALLA",
    "ambience_cue": "AMB",
    "music_cue": "MX",
    "silent_action": "SILENCE",
    "reaction_beat": "PFX",
    "transition_bridge": "MX",
}


def _timeline_segments(performance_timeline: Optional[Json]) -> List[Json]:
    pt = _as_dict(performance_timeline)
    for key in ("segments", "events", "timeline", "performance_segments", "lines"):
        if isinstance(pt.get(key), list):
            return [x for x in pt[key] if isinstance(x, dict)]
    scenes = []
    for sc in _as_list(pt.get("scenes")):
        if isinstance(sc, dict):
            scenes += [x for x in _as_list(sc.get("segments") or sc.get("beats") or sc.get("lines")) if isinstance(x, dict)]
    return scenes


def build_audio_render_contract(
    *,
    performance_timeline: Json,
    audio_design_packet: Optional[Json] = None,
    adaptation_stem_plan: Optional[Json] = None,
    modality_contract: Optional[Json] = None,
    product_mode: str = "cinematic_audiobook",
) -> Json:
    packet = _as_dict(audio_design_packet)
    stem_plan = _as_dict(adaptation_stem_plan)
    segments = _timeline_segments(performance_timeline)
    modality_rules = _extract_modality_rules(modality_contract, family="audio")

    render_segments: List[Json] = []
    for i, seg in enumerate(segments):
        line_class = str(_first_nonempty(seg.get("line_class"), seg.get("type"), seg.get("segment_type"), default="dialogue")).lower()
        bus = _BUS_BY_LINE_CLASS.get(line_class, "DX_ONSCREEN" if seg.get("speaker_id") or seg.get("speaker") else "PFX")
        speaker_id = str(_first_nonempty(seg.get("speaker_id"), seg.get("speaker"), seg.get("character_id"), default=""))
        render_segments.append({
            "render_segment_id": str(_first_nonempty(seg.get("segment_id"), seg.get("line_id"), default=_stable_id("audio_seg", i, seg))),
            "scene_id": str(_first_nonempty(seg.get("scene_id"), packet.get("scene_id"), default="")),
            "beat_id": str(_first_nonempty(seg.get("beat_id"), default="")),
            "line_class": line_class,
            "bus": bus,
            "speaker_id": speaker_id,
            "text": str(_first_nonempty(seg.get("text"), seg.get("line"), default="")),
            "start_s": seg.get("start_s"),
            "end_s": seg.get("end_s"),
            "duration_s": seg.get("duration_s"),
            "tts_directives": {
                "emotion": str(_first_nonempty(seg.get("emotion"), seg.get("performance_emotion"), default="")),
                "subtext": str(_first_nonempty(seg.get("subtext"), default="")),
                "pace": str(_first_nonempty(seg.get("pace"), seg.get("tempo"), default="")),
                "pause_before_ms": seg.get("pause_before_ms"),
                "pause_after_ms": seg.get("pause_after_ms"),
                "overlap_policy": str(_first_nonempty(seg.get("overlap_policy"), default="no_overlap")),
                "mic_distance": str(_first_nonempty(seg.get("mic_distance"), seg.get("spatial_distance"), default="medium")),
                "spatial_position": str(_first_nonempty(seg.get("spatial_position"), seg.get("pan"), default="center")),
                "blocking_reference": str(_first_nonempty(seg.get("blocking_reference"), seg.get("stage_anchor_zone"), default="")),
            },
            "render_policy": "synthesize_speech" if bus.startswith("DX") or bus.startswith("VO") or bus == "NARRATOR" else "render_cue_or_silence",
            "lipsync_relevance": bus == "DX_ONSCREEN",
        })

    required_foley = _stringify_list(packet.get("required_foley") or packet.get("foley") or packet.get("sound"))
    required_ambience = _stringify_list(packet.get("ambience") or packet.get("soundscape") or packet.get("required_ambience"))
    music_motifs = _stringify_list(packet.get("music_motif_ids") or _as_dict(packet.get("music")).get("motif_ids") or packet.get("music_mood"))

    return {
        "artifact_type": "audio_render_contract",
        "audio_render_contract_id": _stable_id("audio_render_contract", _as_dict(performance_timeline).get("performance_timeline_id"), packet.get("scene_id"), product_mode),
        "version": "1.0",
        "product_mode": product_mode,
        "scene_id": packet.get("scene_id"),
        "stem_plan_id": stem_plan.get("adaptation_stem_plan_id") or stem_plan.get("stem_plan_id"),
        "render_segments": render_segments,
        "stem_buses": _dedupe_keep_order([x["bus"] for x in render_segments] + ["FX", "FOLEY", "AMB", "MX"]),
        "sound_design_requirements": {
            "soundscape_id": str(_first_nonempty(packet.get("soundscape_id"), packet.get("location_id"), default="")),
            "required_foley": required_foley,
            "required_ambience": required_ambience,
            "music_motif_ids": music_motifs,
            "narrator_bridge_policy": str(_first_nonempty(packet.get("narrator_bridge_policy"), default="sparse")),
            "audio_only_notes": _stringify_list(packet.get("audiobook_notes") or packet.get("audio_only_production_notes")),
        },
        "modality_rules": modality_rules,
        "required_output_metadata": ["speaker_ids", "line_classes", "stem_buses", "sound_cue_ids", "music_motif_ids", "timeline_s3_uri"],
        "summary": {
            "segment_count": len(render_segments),
            "dialogue_segment_count": sum(1 for x in render_segments if x["bus"].startswith("DX")),
            "narrator_segment_count": sum(1 for x in render_segments if x["bus"] in {"NARRATOR", "VO", "VO_INTERNAL"}),
            "fx_music_cue_count": sum(1 for x in render_segments if x["bus"] in {"FX", "FOLEY", "AMB", "MX", "PFX"}),
        },
    }


# ---------------------------------------------------------------------------
# Motion comic panel planner
# ---------------------------------------------------------------------------

def _beats_from_ams_or_step(ams: Optional[Json] = None, step_outline: Optional[Json] = None) -> List[Json]:
    beats: List[Json] = []
    st = _as_dict(step_outline)
    for scene in _as_list(st.get("scene_cards") or st.get("scenes")):
        if isinstance(scene, dict):
            base = {"scene_id": _scene_id(scene), "source_beat_ids": scene.get("source_beat_ids") or []}
            # Step outline scenes are themselves coarse beats for panel planning.
            beats.append({**base, "beat_id": str(_first_nonempty(scene.get("scene_card_id"), default=_stable_id("scene_card", scene))), "story_function": scene.get("dramatic_function"), "visual_intent": scene.get("visual_strategy"), "audio_intent": scene.get("audio_strategy")})
    a = _as_dict(ams)
    for scene in _as_list(a.get("scenes")):
        if not isinstance(scene, dict):
            continue
        sid = _scene_id(scene)
        for b in _as_list(scene.get("beats")):
            if isinstance(b, dict):
                beats.append({**b, "scene_id": sid})
    return beats


def build_motion_comic_panel_plan(
    *,
    motion_comic_design_packet: Json,
    scene_blocking_plan: Optional[Json] = None,
    adaptation_master_script: Optional[Json] = None,
    step_outline: Optional[Json] = None,
    panel_density: str = "balanced",
) -> Json:
    packet = _as_dict(motion_comic_design_packet)
    blocking = _as_dict(scene_blocking_plan)
    beats = _beats_from_ams_or_step(adaptation_master_script, step_outline)
    scene_id = str(_first_nonempty(packet.get("scene_id"), blocking.get("scene_id"), _scene_id(packet), default="scene_unknown"))
    beats = [b for b in beats if not b.get("scene_id") or str(b.get("scene_id")) == scene_id] or [{"beat_id": _stable_id("beat", scene_id), "scene_id": scene_id, "story_function": packet.get("dramatic_function", "scene beat")}]

    max_panels = {"sparse": 3, "balanced": 5, "dense": 8}.get(panel_density, 5)
    selected_beats = beats[:max_panels]
    panels: List[Json] = []
    layer_reqs = {
        "background_cleanplate": packet.get("background_cleanplate") or packet.get("background_cleanplate_required") or True,
        "character_layers": _as_list(packet.get("character_layers") or packet.get("character_full_body_layers")),
        "face_micro_motion_layers": _as_list(packet.get("face_micro_motion_layers")),
        "prop_layers": _as_list(packet.get("prop_layers") or packet.get("prop_interaction_layers")),
        "foreground_layers": _as_list(packet.get("foreground_layers")),
    }

    for i, beat in enumerate(selected_beats, 1):
        beat_id = str(_first_nonempty(beat.get("beat_id"), default=_stable_id("beat", i, beat)))
        line_class = str(_first_nonempty(beat.get("line_class"), beat.get("beat_type"), default="story_panel"))
        panels.append({
            "panel_id": f"{scene_id}_panel_{i:03d}",
            "scene_id": scene_id,
            "beat_id": beat_id,
            "source_beat_ids": _stringify_list(beat.get("source_beat_ids")),
            "panel_function": str(_first_nonempty(beat.get("story_function"), beat.get("plot_function"), beat.get("beat_category"), default="advance story beat")),
            "line_class": line_class,
            "composition_intent": str(_first_nonempty(beat.get("panel_hint"), beat.get("visual_intent"), packet.get("comic_motion_notes"), default="readable comic composition")),
            "motion_intent": _motion_intent_for_line_class(line_class),
            "required_layers": deepcopy(layer_reqs),
            "speech_or_caption_policy": _speech_policy_for_line_class(line_class),
            "duration_target_s": _first_nonempty(beat.get("duration_target_s"), default=3.0),
        })

    return {
        "artifact_type": "motion_comic_panel_plan",
        "motion_comic_panel_plan_id": _stable_id("motion_panel_plan", scene_id, panel_density, len(panels)),
        "version": "1.0",
        "scene_id": scene_id,
        "panel_density": panel_density,
        "panels": panels,
        "required_output_metadata": ["panel_id", "scene_id", "beat_id", "layer_manifest_id", "detected_character_ids", "detected_prop_ids", "continuity_score"],
        "summary": {"panel_count": len(panels), "requires_cleanplate": bool(layer_reqs["background_cleanplate"])},
    }


def _motion_intent_for_line_class(line_class: str) -> str:
    lc = line_class.lower()
    if "dialogue" in lc:
        return "subtle face/mouth micro-motion plus speaker emphasis"
    if "reaction" in lc:
        return "eye, breath, and posture micro-motion"
    if "action" in lc:
        return "layer parallax and prop/hand motion"
    if "music" in lc or "ambience" in lc:
        return "slow atmospheric parallax"
    return "subtle cinematic panel hold"


def _speech_policy_for_line_class(line_class: str) -> str:
    lc = line_class.lower()
    if "dialogue" in lc:
        return "speech_balloon_or_dialogue_rail"
    if "narrator" in lc or "voice_over" in lc:
        return "caption_or_voiceover_rail"
    return "no_text_unless_required_for_clarity"


# ---------------------------------------------------------------------------
# Render metadata normalization and validation
# ---------------------------------------------------------------------------

def normalize_render_asset_metadata(
    *,
    render_asset: Json,
    contract: Optional[Json] = None,
    detector_output: Optional[Json] = None,
    asset_type: str = "visual",
) -> Json:
    asset = deepcopy(_as_dict(render_asset))
    contract = _as_dict(contract)
    det = _as_dict(detector_output)

    # Pull scene/beat/shot from contract where possible.
    scene_id = _first_nonempty(asset.get("scene_id"), contract.get("scene_id"), default="")
    beat_id = _first_nonempty(asset.get("beat_id"), contract.get("beat_id"), default="")
    shot_id = _first_nonempty(asset.get("shot_id"), contract.get("shot_id"), default="")

    metadata = deepcopy(_as_dict(asset.get("metadata") or asset.get("meta")))
    metadata.update({
        "asset_type": asset_type,
        "scene_id": scene_id,
        "beat_id": beat_id,
        "shot_id": shot_id,
        "source_contract_id": _first_nonempty(contract.get("shot_contract_id"), contract.get("image_render_context_pack_id"), contract.get("audio_render_contract_id"), contract.get("motion_comic_panel_plan_id"), default=""),
        "required_canon_fact_ids": _dedupe_keep_order(_stringify_list(asset.get("required_canon_fact_ids")) + _stringify_list(contract.get("required_canon_fact_ids"))),
        "required_modality_entry_ids": _dedupe_keep_order(_stringify_list(asset.get("required_modality_entry_ids")) + _stringify_list(contract.get("required_modality_entry_ids"))),
        "required_department_entry_ids": _dedupe_keep_order(_stringify_list(asset.get("required_department_entry_ids")) + _stringify_list(contract.get("required_department_entry_ids"))),
        "detected_character_ids": _dedupe_keep_order(_stringify_list(det.get("detected_character_ids") or metadata.get("detected_character_ids"))),
        "detected_costume_ids": _dedupe_keep_order(_stringify_list(det.get("detected_costume_ids") or metadata.get("detected_costume_ids"))),
        "detected_prop_ids": _dedupe_keep_order(_stringify_list(det.get("detected_prop_ids") or metadata.get("detected_prop_ids"))),
        "detected_location_id": str(_first_nonempty(det.get("detected_location_id"), metadata.get("detected_location_id"), default="")),
        "detected_weather": str(_first_nonempty(det.get("detected_weather"), metadata.get("detected_weather"), default="")),
        "detected_time_of_day": str(_first_nonempty(det.get("detected_time_of_day"), metadata.get("detected_time_of_day"), default="")),
        "continuity_score": _first_nonempty(det.get("continuity_score"), metadata.get("continuity_score"), default=None),
        "style_score": _first_nonempty(det.get("style_score"), metadata.get("style_score"), default=None),
        "qc_state": str(_first_nonempty(det.get("qc_state"), metadata.get("qc_state"), default="unknown")),
        "repair_ticket_ids": _dedupe_keep_order(_stringify_list(metadata.get("repair_ticket_ids"))),
    })
    asset["metadata"] = metadata
    asset["scene_id"] = scene_id
    asset["beat_id"] = beat_id
    if shot_id:
        asset["shot_id"] = shot_id
    return asset


def validate_render_contract_bundle(bundle: Json) -> Json:
    issues: List[Json] = []

    def issue(severity: str, code: str, message: str, path: str) -> None:
        issues.append({"severity": severity, "code": code, "message": message, "path": path})

    for key in ("image_render_context_pack", "image_prompt_contract", "video_render_contract", "audio_render_contract", "motion_comic_panel_plan"):
        obj = bundle.get(key)
        if obj is not None and not isinstance(obj, dict):
            issue("blocker", "invalid_contract_type", f"{key} must be an object", key)

    vrc = _as_dict(bundle.get("video_render_contract"))
    for i, sc in enumerate(_as_list(vrc.get("shot_contracts"))):
        if not isinstance(sc, dict):
            issue("blocker", "invalid_shot_contract", "shot contract must be object", f"video_render_contract.shot_contracts[{i}]")
            continue
        if not sc.get("shot_id"):
            issue("blocker", "missing_shot_id", "shot contract missing shot_id", f"video_render_contract.shot_contracts[{i}]")
        if sc.get("audio_sync_policy") == "drive_lipsync_from_dialogue_stem" and not sc.get("lipsync_target_id"):
            issue("repair", "missing_lipsync_target", "lipsync shot needs lipsync_target_id", f"video_render_contract.shot_contracts[{i}]")

    arc = _as_dict(bundle.get("audio_render_contract"))
    if arc and not _as_list(arc.get("render_segments")):
        issue("blocker", "empty_audio_render_contract", "audio render contract has no render segments", "audio_render_contract.render_segments")

    mpp = _as_dict(bundle.get("motion_comic_panel_plan"))
    if mpp and not _as_list(mpp.get("panels")):
        issue("repair", "empty_panel_plan", "motion comic panel plan has no panels", "motion_comic_panel_plan.panels")

    return {
        "artifact_type": "render_contract_validation_report",
        "render_contract_validation_report_id": _stable_id("render_contract_validation", bundle.get("bundle_id"), issues),
        "status": "passed" if not issues else ("blocked" if any(i["severity"] == "blocker" for i in issues) else "needs_repair"),
        "issues": issues,
        "summary": {"issue_count": len(issues), "blocker_count": sum(1 for i in issues if i["severity"] == "blocker")},
    }


def compile_renderer_contract_bundle(
    *,
    scene_department_packet: Json,
    department_bibles_bundle: Optional[Json] = None,
    production_breakdown_manifest: Optional[Json] = None,
    modality_contract: Optional[Json] = None,
    canon_contract: Optional[Json] = None,
    camera_script: Optional[Json] = None,
    performance_timeline: Optional[Json] = None,
    audio_design_packet: Optional[Json] = None,
    adaptation_stem_plan: Optional[Json] = None,
    motion_comic_design_packet: Optional[Json] = None,
    scene_blocking_plan: Optional[Json] = None,
    adaptation_master_script: Optional[Json] = None,
    step_outline: Optional[Json] = None,
    existing_reference_assets: Optional[Sequence[Json]] = None,
) -> Json:
    reference_locks = build_reference_lock_manifest(
        department_bibles_bundle=department_bibles_bundle,
        production_breakdown_manifest=production_breakdown_manifest,
        existing_reference_assets=existing_reference_assets,
    )
    image_context = build_image_render_context_pack(
        scene_department_packet=scene_department_packet,
        department_bibles_bundle=department_bibles_bundle,
        modality_contract=modality_contract,
        canon_contract=canon_contract,
        reference_lock_manifest=reference_locks,
        render_mode="image_or_keyframe",
    )
    image_prompt = compile_image_prompt_from_context_pack(image_context)
    video_contract = build_video_render_contract(
        camera_script=camera_script or {"shots": []},
        scene_department_packets=[scene_department_packet],
        production_breakdown_manifest=production_breakdown_manifest,
        department_bibles_bundle=department_bibles_bundle,
        modality_contract=modality_contract,
        reference_lock_manifest=reference_locks,
    )
    audio_contract = build_audio_render_contract(
        performance_timeline=performance_timeline or {"segments": []},
        audio_design_packet=audio_design_packet,
        adaptation_stem_plan=adaptation_stem_plan,
        modality_contract=modality_contract,
    )
    panel_plan = build_motion_comic_panel_plan(
        motion_comic_design_packet=motion_comic_design_packet or {"scene_id": _scene_id(scene_department_packet)},
        scene_blocking_plan=scene_blocking_plan,
        adaptation_master_script=adaptation_master_script,
        step_outline=step_outline,
    )
    bundle = {
        "artifact_type": "renderer_contract_bundle",
        "bundle_id": _stable_id("renderer_bundle", _scene_id(scene_department_packet), _script_version_id(scene_department_packet)),
        "version": "1.0",
        "reference_lock_manifest": reference_locks,
        "image_render_context_pack": image_context,
        "image_prompt_contract": image_prompt,
        "video_render_contract": video_contract,
        "audio_render_contract": audio_contract,
        "motion_comic_panel_plan": panel_plan,
    }
    bundle["validation_report"] = validate_render_contract_bundle(bundle)
    return bundle
