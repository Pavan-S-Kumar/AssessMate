from __future__ import annotations
from typing import Any, Dict
from boock.render_contracts import compile_image_prompt_from_context_pack


def run_build_image_prompt_from_render_context(input_payload: Dict[str, Any]) -> Dict[str, Any]:
    prompt_contract = compile_image_prompt_from_context_pack(
        input_payload["image_render_context_pack"],
        include_json_attachment=bool(input_payload.get("include_json_attachment", True)),
    )
    return {**input_payload, "image_prompt_contract": prompt_contract}
