from __future__ import annotations
from typing import Any, Dict
from boock.render_contracts import build_video_render_contract


def run_build_video_render_contract_from_camera_script(input_payload: Dict[str, Any]) -> Dict[str, Any]:
    contract = build_video_render_contract(
        camera_script=input_payload["camera_script"],
        scene_department_packets=input_payload.get("scene_department_packets") or ([input_payload["scene_department_packet"]] if input_payload.get("scene_department_packet") else None),
        production_breakdown_manifest=input_payload.get("production_breakdown_manifest"),
        department_bibles_bundle=input_payload.get("department_bibles_bundle"),
        modality_contract=input_payload.get("modality_contract"),
        reference_lock_manifest=input_payload.get("reference_lock_manifest"),
    )
    return {**input_payload, "video_render_contract": contract}
