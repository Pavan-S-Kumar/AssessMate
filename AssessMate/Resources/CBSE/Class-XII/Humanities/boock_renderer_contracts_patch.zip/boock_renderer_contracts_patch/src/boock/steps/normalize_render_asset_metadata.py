from __future__ import annotations
from typing import Any, Dict
from boock.render_contracts import normalize_render_asset_metadata


def run_normalize_render_asset_metadata(input_payload: Dict[str, Any]) -> Dict[str, Any]:
    asset = normalize_render_asset_metadata(
        render_asset=input_payload["render_asset"],
        contract=input_payload.get("contract"),
        detector_output=input_payload.get("detector_output"),
        asset_type=str(input_payload.get("asset_type") or "visual"),
    )
    return {**input_payload, "normalized_render_asset": asset}
