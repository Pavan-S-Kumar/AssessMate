"""Renderer contract adapters for Boock multimodal pipelines."""

from .contracts import (
    build_reference_lock_manifest,
    build_image_render_context_pack,
    compile_image_prompt_from_context_pack,
    build_video_render_contract,
    build_audio_render_contract,
    build_motion_comic_panel_plan,
    normalize_render_asset_metadata,
    validate_render_contract_bundle,
    compile_renderer_contract_bundle,
)

__all__ = [
    "build_reference_lock_manifest",
    "build_image_render_context_pack",
    "compile_image_prompt_from_context_pack",
    "build_video_render_contract",
    "build_audio_render_contract",
    "build_motion_comic_panel_plan",
    "normalize_render_asset_metadata",
    "validate_render_contract_bundle",
    "compile_renderer_contract_bundle",
]
