# Boock Renderer Contracts Patch

This patch wires the upstream story/production improvements into the downstream renderers. It makes image, video, audio, and motion-comic generation consume structured contracts instead of raw prose or loose prompts.

It is a drop-in patch bundle, not an in-place repo edit.

## Why this patch exists

The prior Boock enhancements created the right upstream stack:

```text
Canon / continuity
  -> Screenwriter Beat Sheet
  -> Step Outline
  -> Adaptation Master Script
  -> Production Breakdown
  -> Department Bibles
  -> Scene Blocking
  -> Camera / Performance / Motion-Comic plans
```

But renderers only benefit if they consume those artifacts directly. This patch adds the contract layer that sits immediately before rendering:

```text
scene_department_packet
+ department_bibles_bundle
+ modality/canon contracts
+ reference locks
+ camera_script / performance_timeline / motion_comic_design_packet
  -> renderer_contract_bundle
  -> image/video/audio/comic renderers
  -> normalized render metadata
  -> production continuity validator
```

## What it adds

Core module:

```text
src/boock/render_contracts/contracts.py
```

Runner steps:

```text
build_reference_lock_manifest
build_image_render_context_pack
build_image_prompt_from_render_context
build_video_render_contract_from_camera_script
build_audio_render_contract_from_performance_timeline
build_motion_comic_panel_plan
normalize_render_asset_metadata
compile_renderer_contract_bundle
validate_render_contract_bundle
```

Contracts and examples:

```text
contracts/renderer_contract_bundle_schema.json
contracts/prompt_contract.txt
examples/example_payload.json
examples/example_renderer_contract_bundle.json
```

## New artifacts

### `reference_lock_manifest`

Creates stable reusable locks for:

```text
character
costume
prop
location
hair_makeup
character_appearance
color_lighting
```

This is the bridge from department bibles to reference images, LoRAs, voice refs, prop sheets, or asset-library IDs.

### `image_render_context_pack`

A mandatory image/keyframe prompt context containing:

```text
scene_id / beat_id / shot_id
script_version_id
source_scope_ids
required_canon_fact_ids
required_modality_entry_ids
required_department_entry_ids
characters / costumes / props / hero props
location / time_of_day / weather
set dressing / VFX / palette / lighting
camera requirements
story intent
reference locks
negative constraints
required detector metadata
```

### `image_prompt_contract`

A renderer-friendly prompt object built from the context pack. It contains:

```text
prompt
negative_prompt
reference_locks
required_detector_metadata
context_pack
```

Image renderers should consume this instead of raw chapter text.

### `video_render_contract`

Compiles `camera_script` into shot-level contracts. Each shot carries:

```text
shot_id / scene_id / beat_id
image_render_context_pack
prompt_contract
audio_sync_policy
lipsync_target_id
editorial_lock
preferred_render_policy
required_output_metadata
```

Important behavior:

```text
onscreen_dialogue -> drive_lipsync_from_dialogue_stem
narrator/offscreen/VO -> do_not_drive_lipsync_use_broll_or_reaction
silent/action/ambience -> no_lipsync_visual_action_or_ambience
```

### `audio_render_contract`

Compiles `adaptation_performance_timeline` into a bus/stem-aware render plan:

```text
DX_ONSCREEN
DX_OFFSCREEN
NARRATOR
VO
VO_INTERNAL
WALLA
PFX
FOLEY
AMB
MX
```

Every speech segment includes TTS/performance directives:

```text
emotion
subtext
pace
pause_before_ms
pause_after_ms
overlap_policy
mic_distance
spatial_position
blocking_reference
```

### `motion_comic_panel_plan`

Turns AMS/step-outline beats and `motion_comic_design_packet` into panel contracts:

```text
panel_id / scene_id / beat_id
panel_function
composition_intent
motion_intent
background cleanplate requirement
character/body/face/prop layers
speech_or_caption_policy
duration_target_s
```

This feeds the segmented character-layer pipeline.

### `normalized_render_asset`

Normalizes generated image/video/comic/audio metadata so validators can inspect outputs:

```text
scene_id / beat_id / shot_id
required_canon_fact_ids
required_modality_entry_ids
required_department_entry_ids
detected_character_ids
detected_costume_ids
detected_prop_ids
detected_location_id
detected_weather
detected_time_of_day
continuity_score
style_score
qc_state
repair_ticket_ids
```

## Recommended pipeline insertion

```text
build_screenwriter_beat_sheet
  -> build_step_outline_from_beat_sheet
  -> generate_adaptation_master_script
  -> build_production_breakdown_manifest
  -> build_department_bibles_from_breakdown
  -> build_scene_department_packet
  -> build_reference_lock_manifest
  -> generate_scene_blocking_plan
  -> build_camera_script_from_blocking
  -> build_audio_design_packet
  -> build_motion_comic_design_packet
  -> compile_renderer_contract_bundle
  -> image/video/audio/motion-comic renderers
  -> normalize_render_asset_metadata
  -> build_production_continuity_validation_report
  -> repair or publish
```

## Example usage

```python
from boock.render_contracts import compile_renderer_contract_bundle

bundle = compile_renderer_contract_bundle(
    scene_department_packet=scene_department_packet,
    department_bibles_bundle=department_bibles_bundle,
    production_breakdown_manifest=production_breakdown_manifest,
    modality_contract=modality_contract,
    canon_contract=canon_contract,
    camera_script=camera_script,
    performance_timeline=performance_timeline,
    audio_design_packet=audio_design_packet,
    adaptation_stem_plan=adaptation_stem_plan,
    motion_comic_design_packet=motion_comic_design_packet,
    scene_blocking_plan=scene_blocking_plan,
    adaptation_master_script=adaptation_master_script,
    step_outline=step_outline,
)
```

Then pass:

```text
bundle["image_prompt_contract"]              -> image/keyframe renderer
bundle["video_render_contract"]             -> shot renderer / cinematic timeline compiler
bundle["audio_render_contract"]             -> TTS/stem renderer
bundle["motion_comic_panel_plan"]           -> panel/layer planner
bundle["reference_lock_manifest"]           -> image/reference asset manager
```

## Validation

I ran the included tests manually using Python's no-site mode because site initialization in this container hung when PYTHONPATH was set.

```text
7 tests passed
compileall passed
```

## Design rule

No production renderer should start from raw prose alone. Every generated asset should be traceable to:

```text
canon facts
screenwriter beat / AMS beat
scene department packet
department bible entries
modality bible entries
reference locks
render contract
```
